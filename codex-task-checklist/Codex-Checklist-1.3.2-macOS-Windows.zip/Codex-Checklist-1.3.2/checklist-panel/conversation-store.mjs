import fs from 'node:fs';
import path from 'node:path';
import {createHash,randomUUID} from 'node:crypto';

const uuid=/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
// Only request-scoped chat identifiers. Transport sessions and process env are
// deliberately excluded: one process/connection can serve multiple chats.
export function conversationKey(extra={}){
 const meta=extra._meta??{},values=[];
 const add=v=>{if(typeof v==='string'&&v.trim()&&v.length<=4096)values.push(v.trim());};
 for(const k of ['openai/threadId','openai/thread_id','codexThreadId','codex_thread_id','threadId','thread_id'])add(meta[k]);
 let turn=meta['x-codex-turn-metadata'];
 if(typeof turn==='string')try{turn=JSON.parse(turn);}catch{turn=null;}
 if(turn&&typeof turn==='object')add(turn.thread_id);
 const unique=[...new Set(values)];
 if(unique.length>1)throw Error('请求中的会话标识不一致，未自动选择清单');
 const id=unique[0]??(typeof turn?.chatgpt_conversation_id==='string'?turn.chatgpt_conversation_id:null);
 if(!id||id.length>4096)return null;
 return createHash('sha256').update((unique.length?'codex-thread:':'chatgpt-conversation:')+id).digest('hex');
}
function readJson(file){const s=fs.lstatSync(file);if(!s.isFile()||s.size>32768)throw Error('会话关联文件异常');return JSON.parse(fs.readFileSync(file,'utf8'));}
function directory(dir){fs.mkdirSync(dir,{recursive:true,mode:0o700});if(fs.lstatSync(dir).isSymbolicLink())throw Error('会话关联目录不能是链接');}
function publish(file,data){
 directory(path.dirname(file));const tmp=file+'.'+randomUUID()+'.tmp';let fd;
 try{fd=fs.openSync(tmp,'wx',0o600);fs.writeFileSync(fd,JSON.stringify(data));fs.fsyncSync(fd);fs.closeSync(fd);fd=undefined;fs.linkSync(tmp,file);if(process.platform!=='win32'){const d=fs.openSync(path.dirname(file),'r');try{fs.fsyncSync(d);}finally{fs.closeSync(d);}}}
 finally{if(fd!==undefined)fs.closeSync(fd);fs.rmSync(tmp,{force:true});}
}
export class ConversationStore{
 constructor(root,readTask){this.root=path.join(root,'.conversations-v1');this.readTask=readTask;}
 dir(key){if(!/^[a-f0-9]{64}$/.test(key))throw Error('会话标识无效');return path.join(this.root,key);}
 associate(key,state){
  if(!key)return false;
  if(!uuid.test(state.taskId))throw Error('清单标识无效');
  const file=path.join(this.dir(key),'tasks',state.taskId+'.json');
  try{publish(file,{schemaVersion:1,taskId:state.taskId,createdAt:state.createdAt});}
  catch(e){if(e.code!=='EEXIST')throw e;}
  return true;
 }
 preference(key){
  const dir=path.join(this.dir(key),'selection');let files;
  try{if(fs.lstatSync(dir).isSymbolicLink())throw Error('选择目录不能是链接');files=fs.readdirSync(dir);}catch(e){if(e.code==='ENOENT')return{revision:0,taskId:null};throw e;}
  const revs=files.filter(f=>/^\d+\.json$/.test(f)).map(f=>Number(f.slice(0,-5)));
  if(!revs.length)return{revision:0,taskId:null};
  const rev=Math.max(...revs),s=readJson(path.join(dir,rev+'.json'));
  if(s.schemaVersion!==1||s.revision!==rev||(s.taskId!==null&&!uuid.test(s.taskId)))throw Error('已保存的面板选择损坏，未切换到其他任务');
  return {...s,selectedAt:s.selectedAt??new Date(fs.statSync(path.join(dir,rev+'.json')).mtimeMs).toISOString()};
 }
 resolve(key){
  if(!key)return{identified:false,conversationKey:null,taskId:null,mode:'auto',reason:'missing_identity',selectionRevision:0};
  const pref=this.preference(key),base={identified:true,conversationKey:key,selectionRevision:pref.revision};
  const dir=path.join(this.dir(key),'tasks');let names;
  try{if(fs.lstatSync(dir).isSymbolicLink())throw Error('关联目录不能是链接');names=fs.readdirSync(dir);}catch(e){if(e.code==='ENOENT')names=[];else throw e;}
  const tasks=[];let unreadable=0;
  for(const name of names){if(!uuid.test(name.slice(0,-5))||!name.endsWith('.json'))continue;
   try{const ref=readJson(path.join(dir,name));if(ref.taskId+'.json'!==name)throw Error('关联身份错误');tasks.push(this.readTask(ref.taskId));}catch{unreadable++;}
  }
  tasks.sort((a,b)=>b.createdAt.localeCompare(a.createdAt)||b.taskId.localeCompare(a.taskId));
  const chosen=tasks[0];
  // A manual history view persists until this chat creates another task. Task
  // updates do not change this watermark or steal selection from another chat.
  const newTask=pref.latestTaskId!==undefined?pref.latestTaskId!==(chosen?.taskId??null):Boolean(chosen&&pref.selectedAt&&chosen.createdAt>pref.selectedAt);
  if(pref.taskId&&!newTask){try{this.readTask(pref.taskId);return{...base,taskId:pref.taskId,mode:'manual',reason:'saved_selection'};}catch{return{...base,taskId:null,mode:'manual',reason:'selected_unavailable'};}}
  const active=chosen?.plan.some(s=>!['completed','cancelled'].includes(s.status));
  return{...base,taskId:chosen?.taskId??null,mode:'auto',reason:active?'recent_active':chosen?'recent_completed':'no_association',unreadable};
 }
 select(key,taskId,expectedRevision){
  if(!key)throw Error('当前请求缺少会话标识，无法保存选择');
  if(taskId!==null)this.readTask(taskId);
  const pref=this.preference(key);
  if(pref.revision!==expectedRevision)return{conflict:true,...this.resolve(key)};
  const refs=path.join(this.dir(key),'tasks');let latest=null;
  try{for(const name of fs.readdirSync(refs)){if(!uuid.test(name.slice(0,-5))||!name.endsWith('.json'))continue;const ref=readJson(path.join(refs,name));if(ref.taskId+'.json'!==name)continue;if(!latest||ref.createdAt>latest.createdAt||(ref.createdAt===latest.createdAt&&ref.taskId>latest.taskId))latest=ref;}}catch(e){if(e.code!=='ENOENT')throw e;}
  try{publish(path.join(this.dir(key),'selection',(pref.revision+1)+'.json'),{schemaVersion:1,revision:pref.revision+1,taskId,selectedAt:new Date().toISOString(),latestTaskId:latest?.taskId??null});}
  catch(e){if(e.code==='EEXIST')return{conflict:true,...this.resolve(key)};throw e;}
  return this.resolve(key);
 }
}
