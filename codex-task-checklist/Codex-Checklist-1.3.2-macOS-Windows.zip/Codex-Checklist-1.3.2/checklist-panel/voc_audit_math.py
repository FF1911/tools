"""Pure audit math extracted from voc-deepdive 1.85.2 metrics.py.
Only SELECT queries; no imports of collectors, drivers, or command entrypoints.
Source SHA256: 3680faa750b66fc799dd54c8e6232c578ae9aadeb266ea80753bb9545584c245
"""
import json,math,sqlite3
from types import SimpleNamespace
SCREEN_MIN_RECALL=0.95
SCREEN_MIN_KAPPA=0.80
def audit_rounds(c,task):
 try:return [(int(r),set(json.loads(b))) for r,b in c.execute('SELECT round,batches FROM screen_audit_rounds WHERE task=? ORDER BY round',(task,))]
 except sqlite3.Error:return []
jp=SimpleNamespace(screen_task_of=lambda t:t+'__screen',audit_task_of=lambda t:t+'__audit',audit2_task_of=lambda t:t+'__audit2',audit_rounds=audit_rounds)
def _wilson(k, n, z=1.96):
    if n == 0:
        return (0.0, 1.0)
    p = k / n
    d = 1 + z * z / n
    mid = p + z * z / (2 * n)
    r = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n))
    return (max(0.0, (mid - r) / d), min(1.0, (mid + r) / d))

def _kappa_2x2(N1, N0, p1, p0):
    """初筛判相关 N1 条、判不相关 N0 条，两层里真相关的比例分别是 p1、p0 时，初筛对"真值"的 κ。"""
    N = N1 + N0
    tp, fp, fn, tn = (N1 * p1, N1 * (1 - p1), N0 * p0, N0 * (1 - p0))
    po = (tp + tn) / N
    pe = ((tp + fp) * (tp + fn) + (fn + tn) * (fp + tn)) / N / N
    return (po - pe) / (1 - pe) if pe < 1 else None

def _audit_labels(c, task):
    """复核结果：判相关但举证没站住的（judge_cli 标了 evidence_void）按不相关算（v1.67.0）。
    复核者拿「谢谢新朋友」、帖子标题或父评论当依据判出来的"漏判"，每条要外推几百倍，
    不排除掉就会把召回压到线下、触发一整轮不必要的重判。"""
    out = {}
    for p, cid, a, pj in c.execute('SELECT post_id, comment_id, applicable, payload_json FROM codings WHERE task=?', (task,)):
        void = False
        if a and pj:
            try:
                void = bool((json.loads(pj) or {}).get('evidence_void'))
            except ValueError:
                void = False
        out[p, cid or ''] = 0 if void else a
    return out

def screen_audit(c, task, min_recall=SCREEN_MIN_RECALL, min_kappa=SCREEN_MIN_KAPPA):
    """初筛验收：复核者（比初筛更强的模型）对分层抽样的盲判结果当真值，按两层实际规模加权估全池。

      判相关那层 N1 条里真相关的比例 p1（= 精确率），判不相关那层 N0 条里真相关的比例 p0（= 漏判率）
      召回 = N1·p1 / (N1·p1 + N0·p0)；κ 由同一张 2×2 表算出
    区间用 Wilson 区间的最不利组合（p1 取下限、p0 取上限算召回下限），样本少时结论会标"不够确定"。
    判相关那层没抽复核时，退回用打码段的确认率当 p1。
    有二次确认（<task>__audit2，另一个强模型重判复核与初筛不一致的条目）时：两个复核者都说初筛判错
    才算初筛错，结论按这个口径下；单复核者口径的召回 / κ 一并给出，差得多说明复核者自己的噪声不小。"""
    st, at = (jp.screen_task_of(task), jp.audit_task_of(task))
    scr = {(p, cid or ''): a for p, cid, a in c.execute('SELECT post_id, comment_id, applicable FROM codings WHERE task=?', (st,))}
    if not scr:
        raise SystemExit(f'没有初筛结果（task={st}）——初筛验收只对做过全库语义初筛的项目有意义')
    aud = _audit_labels(c, at)
    if not aud:
        raise SystemExit(f'没有验收复核结果（task={at}）。流程：judge_pipeline.py prepare --task {task} --frame screen-audit --out <任务目录>/screen_audit/batches → judge_cli.py run --screen（用比初筛更强的模型）→ ingest（清单带 audit，会自动写进 __audit）')
    aud2 = _audit_labels(c, jp.audit2_task_of(task))
    single = None
    disc = [k for k in aud if k in scr and aud[k] != scr[k]]
    confirm = None
    if aud2:
        rej = [k for k in disc if k in aud2]
        upheld = [k for k in rej if aud2[k] == aud[k]]
        confirm = {'discordant': len(disc), 'rejudged': len(rej), 'confirmed_errors': len(upheld), 'not_rejudged': len(disc) - len(rej)}
        single = _screen_audit_core(c, task, scr, aud, min_recall, min_kappa)
        aud = {k: scr[k] if k in aud2 and aud2[k] != aud[k] and (k in scr) else v for k, v in aud.items()}
    r = _screen_audit_core(c, task, scr, aud, min_recall, min_kappa)
    r['confirm'] = confirm
    rounds = jp.audit_rounds(c, task)
    if rounds:
        covered = set().union(*[b for _, b in rounds])
        sb = {(p, cid or ''): str(b) for p, cid, b in c.execute('SELECT post_id, comment_id, batch FROM codings WHERE task=?', (st,))}
        stale = sum((1 for k in scr if sb.get(k) not in covered))
        r['rounds'] = len(rounds)
        r['uncovered_screen_n'] = stale
        if stale:
            r['verdict'] = '验收过期'
            r['advice'].insert(0, f'有 {stale} 条初筛结果不在任何一轮验收里（验收之后又追加了初筛）：对新增批次单独验收 prepare --task {task} --frame screen-audit --append --audit-round new → 复核 → ingest，再算（按轮次分层估召回）')
    elif r.get('verdict') != '验收过期':
        r['advice'].append('验收没登记轮次（v1.73.0 前做的）：如果验收之后又追加过初筛，这个结论覆盖不到新批次')
    if not aud2 and disc and (r['verdict'] != '通过'):
        r['advice'].insert(0, f'复核者自己也会判错：先把复核与初筛不一致的 {len(disc)} 条交给另一个强模型二次确认（prepare --task {task} --frame audit-confirm → judge_cli run --screen → ingest），两个复核者都说初筛错才算错，再看结论')
    if single is not None:
        r['single_auditor'] = {k: single[k] for k in ('recall', 'recall_ci', 'kappa', 'kappa_ci', 'r0', 'r1', 'missed_est', 'verdict')}
        if confirm['not_rejudged']:
            r['advice'].append(f"还有 {confirm['not_rejudged']} 条不一致的没做二次确认，这几条按单复核者的结论算")
    return r

def _screen_audit_core(c, task, scr, aud, min_recall, min_kappa):
    rounds = jp.audit_rounds(c, task)
    if len(rounds) > 1:
        return _screen_audit_rounds(c, task, scr, aud, rounds, min_recall, min_kappa)
    N1 = sum((1 for v in scr.values() if v == 1))
    N0 = sum((1 for v in scr.values() if v == 0))
    s1 = [aud[k] for k in aud if scr.get(k) == 1]
    s0 = [aud[k] for k in aud if scr.get(k) == 0]
    n1, r1 = (len(s1), sum((1 for v in s1 if v == 1)))
    n0, r0 = (len(s0), sum((1 for v in s0 if v == 1)))
    src1 = '验收复核'
    if n1 == 0:
        main = {(p, cid or ''): a for p, cid, a in c.execute('SELECT post_id, comment_id, applicable FROM codings WHERE task=?', (task,))}
        via = [main[k] for k in main if scr.get(k) == 1]
        n1, r1, src1 = (len(via), sum((1 for v in via if v == 1)), '打码段确认率')
    if n0 == 0:
        raise SystemExit('验收样本里没有初筛判不相关的条目，估不了漏判——prepare --frame screen-audit 时 --audit-neg 不能为 0')
    if n1 == 0:
        raise SystemExit('判相关那层既没有复核、也没有打码结果，估不了精确率')
    p1, p0 = (r1 / n1, r0 / n0)
    lo1, hi1 = _wilson(r1, n1)
    lo0, hi0 = _wilson(r0, n0)
    rec = lambda a, b: N1 * a / (N1 * a + N0 * b) if N1 * a + N0 * b else None
    recall, recall_lo, recall_hi = (rec(p1, p0), rec(lo1, hi0), rec(hi1, lo0))
    ks = [k for k in (_kappa_2x2(N1, N0, a, b) for a in (lo1, hi1) for b in (lo0, hi0)) if k is not None]
    kappa = _kappa_2x2(N1, N0, p1, p0)
    passed = recall is not None and kappa is not None and (recall >= min_recall) and (kappa >= min_kappa)
    sure = passed and recall_lo >= min_recall and (min(ks) >= min_kappa)
    verdict = '通过' if sure else '通过（样本不够确定）' if passed else '不通过'
    advice = []
    if recall is not None and recall < min_recall:
        advice.append(f'召回 {recall:.3f} 低于 {min_recall}：初筛约漏判 {N0 * p0:.0f} 条相关条目。换更强一档的初筛模型，或把口径里容易漏的情形写进准入，再重跑判不相关的那部分')
    if kappa is not None and kappa < min_kappa and ((recall or 0) >= min_recall):
        advice.append(f'κ {kappa:.3f} 低于 {min_kappa}，主要是多收（精确率 {p1:.3f}）：打码段会多花钱，份额靠确认率校正；把口径的排除项写全，或换更强一档的初筛模型')
    need_n0 = None
    if passed and (not sure):
        for n in range(n0 + 50, 5001, 50):
            if rec(lo1, _wilson(round(p0 * n), n)[1]) >= min_recall:
                need_n0 = n
                break
        advice.append('点估计过线，但区间下限没过：' + (f'把判不相关那层的复核加到约 {need_n0} 条（--audit-neg {need_n0}）再看' if need_n0 else '复核样本再大也难确定，按不通过处理更稳'))
    return {'task': task, 'N1_screened_in': N1, 'N0_screened_out': N0, 'n1': n1, 'r1': r1, 'n0': n0, 'r0': r0, 'precision_source': src1, 'precision': round(p1, 4), 'miss_rate': round(p0, 4), 'missed_est': round(N0 * p0), 'recall': round(recall, 4) if recall is not None else None, 'recall_ci': [round(recall_lo, 4), round(recall_hi, 4)], 'kappa': round(kappa, 4) if kappa is not None else None, 'kappa_ci': [round(min(ks), 4), round(max(ks), 4)], 'min_recall': min_recall, 'min_kappa': min_kappa, 'verdict': verdict, 'advice': advice, 'need_audit_neg': need_n0}

def _screen_audit_rounds(c, task, scr, aud, rounds, min_recall, min_kappa):
    """多轮验收按轮次分层估召回（v1.73.0）：每轮只代表它覆盖的初筛批次，两层各自按该轮的 N1/N0 外推后相加。
    不分层直接合并会让先验收的那一轮被过度代表（它的样本多、条目来源和漏判率都不同）。"""
    sb = {(p, cid or ''): str(b) for p, cid, b in c.execute('SELECT post_id, comment_id, batch FROM codings WHERE task=?', (jp.screen_task_of(task),))}
    of = {}
    for rn, bs in rounds:
        for b in bs:
            of.setdefault(b, rn)
    tp = fn = 0.0
    tp_lo = fn_hi = tp_hi = fn_lo = 0.0
    N1t = N0t = n1t = n0t = r1t = r0t = 0
    per = []
    for rn, _ in rounds:
        keys = [k for k in scr if of.get(sb.get(k)) == rn]
        N1 = sum((1 for k in keys if scr[k] == 1))
        N0 = sum((1 for k in keys if scr[k] == 0))
        ks = set(keys)
        s1 = [aud[k] for k in aud if k in ks and scr.get(k) == 1]
        s0 = [aud[k] for k in aud if k in ks and scr.get(k) == 0]
        n1, r1 = (len(s1), sum((1 for v in s1 if v == 1)))
        n0, r0 = (len(s0), sum((1 for v in s0 if v == 1)))
        if N1 and (not n1) or (N0 and (not n0)):
            raise SystemExit(f'验收第 {rn} 轮：判相关层抽了 {n1} 条、判不相关层抽了 {n0} 条，有一层没样本，按轮次估不了')
        p1 = r1 / n1 if n1 else 0.0
        p0 = r0 / n0 if n0 else 0.0
        lo1, hi1 = _wilson(r1, n1) if n1 else (0.0, 0.0)
        lo0, hi0 = _wilson(r0, n0) if n0 else (0.0, 0.0)
        tp += N1 * p1
        fn += N0 * p0
        tp_lo += N1 * lo1
        fn_hi += N0 * hi0
        tp_hi += N1 * hi1
        fn_lo += N0 * lo0
        N1t += N1
        N0t += N0
        n1t += n1
        n0t += n0
        r1t += r1
        r0t += r0
        per.append({'round': rn, 'N1': N1, 'N0': N0, 'n1': n1, 'r1': r1, 'n0': n0, 'r0': r0, 'precision': round(p1, 4), 'miss_rate': round(p0, 4), 'missed_est': round(N0 * p0)})
    rec = lambda a, b: a / (a + b) if a + b else None
    recall, recall_lo, recall_hi = (rec(tp, fn), rec(tp_lo, fn_hi), rec(tp_hi, fn_lo))
    p1e, p0e = (tp / N1t if N1t else 0.0, fn / N0t if N0t else 0.0)
    kappa = _kappa_2x2(N1t, N0t, p1e, p0e)
    kl = [k for k in (_kappa_2x2(N1t, N0t, a, b) for a in (tp_lo / N1t if N1t else 0, tp_hi / N1t if N1t else 0) for b in (fn_lo / N0t if N0t else 0, fn_hi / N0t if N0t else 0)) if k is not None]
    passed = recall is not None and kappa is not None and (recall >= min_recall) and (kappa >= min_kappa)
    sure = passed and recall_lo >= min_recall and (min(kl) >= min_kappa)
    verdict = '通过' if sure else '通过（样本不够确定）' if passed else '不通过'
    advice = [] if passed else [f'按轮次分层后召回 {recall:.3f}、κ {kappa:.3f}：各轮漏判估计 ' + '、'.join((f"第 {x['round']} 轮约 {x['missed_est']} 条" for x in per))]
    return {'task': task, 'N1_screened_in': N1t, 'N0_screened_out': N0t, 'n1': n1t, 'r1': r1t, 'n0': n0t, 'r0': r0t, 'precision_source': '验收复核（按轮次分层）', 'precision': round(p1e, 4), 'miss_rate': round(p0e, 4), 'missed_est': round(fn), 'recall': round(recall, 4) if recall is not None else None, 'recall_ci': [round(recall_lo, 4), round(recall_hi, 4)], 'kappa': round(kappa, 4) if kappa is not None else None, 'kappa_ci': [round(min(kl), 4), round(max(kl), 4)], 'min_recall': min_recall, 'min_kappa': min_kappa, 'verdict': verdict, 'advice': advice, 'need_audit_neg': None, 'per_round': per}
