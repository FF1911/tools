import {mountStage} from './voc-stage-view.mjs';
export function mountVoc(document){return mountStage(document,document.getElementById('voc-panel'));}
export function createVocController({fetchState,view}){
 let selected=null,generation=0,request=0;
 return {select(id){selected=id;generation++;view.hide();},async refresh(){const id=selected,token=generation,seq=++request;if(!id)return;try{const s=await fetchState(id);if(token!==generation||seq!==request||id!==selected)return;if(s.taskId!==id)throw Error('任务不匹配');if(!s.available){view.hide();return;}view.draw(s);}catch{if(token===generation&&seq===request)view.error('进度暂时无法刷新；若有旧数据，仅供参考。');}}};
}
