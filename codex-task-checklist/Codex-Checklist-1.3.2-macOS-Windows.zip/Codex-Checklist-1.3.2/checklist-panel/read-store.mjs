import fs from 'node:fs';
import path from 'node:path';
import {z} from 'zod';
export const idSchema=z.string().uuid();
const step=z.object({id:z.string(),step:z.string(),status:z.enum(['pending','in_progress','completed','blocked','cancelled']),note:z.string().optional()});
const schema=z.object({schemaVersion:z.literal(1),taskId:idSchema,title:z.string(),revision:z.number().int().nonnegative(),createdAt:z.string(),updatedAt:z.string(),plan:z.array(step)});
export class ReadStore{
  constructor(root){this.root=root;}
  read(id){
    idSchema.parse(id);
    const dir=path.join(this.root,id);
    if(fs.lstatSync(dir).isSymbolicLink())throw new Error('清单目录不能是链接');
    const revisions=fs.readdirSync(dir).filter(n=>/^\d+\.json$/.test(n)).map(n=>Number(n.slice(0,-5)));
    if(!revisions.length)throw new Error('清单没有保存版本');
    const revision=Math.max(...revisions),file=path.join(dir,revision+'.json');
    const stat=fs.lstatSync(file);
    if(!stat.isFile()||stat.size>1024*1024)throw new Error('清单文件格式异常');
    const state=schema.parse(JSON.parse(fs.readFileSync(file,'utf8')));
    if(state.taskId!==id||state.revision!==revision)throw new Error('清单版本或身份不匹配');
    return state;
  }
  list(){
    let names;try{names=fs.readdirSync(this.root);}catch(e){if(e.code==='ENOENT')return{tasks:[],unreadable:0};throw e;}
    const tasks=[];let unreadable=0;
    for(const id of names){
      if(!idSchema.safeParse(id).success)continue;
      try{const s=this.read(id);tasks.push({taskId:s.taskId,title:s.title,revision:s.revision,updatedAt:s.updatedAt,completed:s.plan.filter(x=>x.status==='completed').length,total:s.plan.length});}
      catch{unreadable++;}
    }
    return{tasks:tasks.sort((a,b)=>b.updatedAt.localeCompare(a.updatedAt)),unreadable};
  }
}
