import {createHash} from 'node:crypto';

export const PANEL_VERSION='0.3.1';
export const PANEL_TITLE='清单面板 · 双卡片';
export const LEGACY_URI='ui://checklist-panel/readonly-v1.html';

// Bind an immutable document to its content address for the lifetime of a server.
// New HTML/CSS/JS receives a new URI; reopening an old URI remains supported.
export function uiResource(html){
 const hash=createHash('sha256').update(html).digest('hex');
 return Object.freeze({html,hash,uri:`ui://checklist-panel/dual-card-${hash}.html`});
}
