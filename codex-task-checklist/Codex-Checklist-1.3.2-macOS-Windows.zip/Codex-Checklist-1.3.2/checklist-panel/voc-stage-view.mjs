import {stageSpecs} from './stage-spec.mjs';
import {processingModel} from './voc-processing-view.mjs';
const n=x=>typeof x==='number'&&Number.isFinite(x)?x.toLocaleString('zh-CN'):'—';
export function stageModel(s){
 if(s.presentation)return s.presentation; // Explicit preview contract; never inferred from file existence.
 const c=s.collection,q=s.quota,p=s.processing;
 const paused=s.execution?.paused===true||s.execution?.status==='paused';
 const collecting=s.phase==='采集评论树';const id=collecting?'collect':'discover';
 const unknownStage=s.phase!=='发现候选'&&!collecting;
 return processingModel(s,{id,title:unknownStage?s.phase:undefined,status:paused?'paused':s.marker?'blocked':q?.stale?'stale':q?.sleeping?'waiting':'observed',
  headline:collecting?`${n(c?.completed)} 帖评论树已采完`:`${n(c?.candidates)} 条去重候选`,
  subtitle:collecting?'完成帖计数来自数据库；目标以本轮实际生效名额为准。':'候选池仍在形成，候选数量不代表采集完成。',
  metrics:[{label:collecting?'已落库评论':'待采集候选',value:collecting?p?.comments:c?.queued,unit:collecting?'条':'帖'},{label:'失败 / 不完整',text:`${n(c?.failed)} / ${n(c?.inflight)}`},{label:'实际采集名额',text:c?.targetCurrent?n(c.target)+' 帖':'尚未确定'}],
  bars:collecting&&c?.targetCurrent&&c?.target>0?[{label:'生效名额内已完成',done:c.completedWithinTarget,total:c.target,unit:'帖'}]:[],
  activity:!paused&&!unknownStage&&!q?.sleeping&&!q?.stale,
  activityText:unknownStage?'当前阶段尚未接入专用计数':collecting?'尚无可核实的本轮进度分母':'发现候选 · 本轮检索总量尚未登记',
  wait:!paused&&q?.sleeping?{until:q.wake_at,reason:q.reason}:null,quota:paused?null:q,
  note:paused?'用户已暂停任务，保留已保存进度；等待明确恢复后继续。':s.marker?'采集停止点需要执行方处理；面板只读。':null,
  details:[`已落库文本 ${n(p?.items)} 条，其中评论 ${n(p?.comments)} 条`,...(p?.tasks??[]).map(t=>`${t.task}：已入库判读 ${n(t.items)} 条，其中适用 ${n(t.applicable)} 条`),...(p?.batches??[]).map(b=>`${b.task}：导出批次文件 ${b.exportedFiles} 份，结果文件 ${b.resultFiles} 份`)]});
}
export function mountStage(document,root){
 root.innerHTML=`<header class="v-head"><strong>VOC 任务进度</strong><span id="voc-updated" class="muted"></span></header><div class="v-heading"><h2 id="voc-phase"></h2><span id="voc-state" class="v-state"></span></div><div id="voc-error" role="status"></div><div id="voc-headline" class="v-headline"></div><div id="voc-bars"></div><div id="voc-activity" class="v-activity"><b></b><span></span></div><div id="voc-metrics" class="v-metrics"></div><div id="voc-parallel" class="v-parallel" hidden></div><div class="v-quota-row"><div id="voc-wait" class="v-wait" hidden><span class="v-wait-dot"></span><strong id="voc-countdown"></strong></div><div id="voc-quota" class="v-quota" hidden></div></div><div id="voc-checks"></div><p id="voc-important" class="muted" hidden></p><details><summary>口径与数据来源</summary><div class="v-route"><span>采集</span><i>›</i><span>语料处理</span><i>›</i><span>交付</span></div><div id="voc-project" class="muted"></div><p id="voc-subtitle" class="muted"></p><p id="voc-wait-reason" class="muted"></p><p id="voc-note" class="muted"></p><div id="voc-details" class="muted"></div><p class="muted">请求配额、帖子名额与条目判读分别统计。数据每 5 秒读取；界面动画不会推进任务。质量验收独立于数量完成度。</p></details>`;
 const el=id=>document.getElementById(id),set=(id,text)=>el(id).textContent=text??'';
 let current=null,offset=0,lastStage=null,failed=false;const bars=new Map();
 function time(){if(!current?.wait)return;if(failed||current.status==='stale'){set('voc-countdown','等待刷新 · 暂不倒计时');return;}const seconds=Math.max(0,Math.ceil(current.wait.until-(Date.now()/1000+offset)));set('voc-countdown',seconds?`配额等待 · ${Math.floor(seconds/60)}:${String(seconds%60).padStart(2,'0')}`:'已到唤醒时刻 · 等待新状态确认');}
 const timer=setInterval(time,1000);timer.unref?.();
 function renderBar(b,index){let node=bars.get(index);if(!node){node=document.createElement('div');node.className='v-progress';node.innerHTML='<div class="v-progress-label"><span></span><strong></strong></div><div class="v-track" role="progressbar"><div class="v-fill"></div></div><small></small>';bars.set(index,node);el('voc-bars').append(node);}
  const valid=Number.isFinite(b.done)&&Number.isFinite(b.total)&&b.total>0&&b.done>=0&&b.done<=b.total;
  node.querySelector('span').textContent=b.label;node.querySelector('strong').textContent=valid?`${n(b.done)} / ${n(b.total)} ${b.unit??''}`:'总量待确认';
  const track=node.querySelector('.v-track');track.setAttribute('aria-label',b.label);track.classList.toggle('v-unknown',!valid);
  for(const a of ['aria-valuemin','aria-valuemax','aria-valuenow'])track.removeAttribute(a);
  if(valid){track.setAttribute('aria-valuemin','0');track.setAttribute('aria-valuemax',b.total);track.setAttribute('aria-valuenow',b.done);}
  node.querySelector('.v-fill').style.width=valid?`${100*b.done/b.total}%`:'0%';
  node.querySelector('small').textContent=valid?`${Math.floor(100*b.done/b.total)}%${b.note?' · '+b.note:''}`:b.note??'缺少可靠分母，不计算百分比';
 }
 return {dispose(){clearInterval(timer);},hide(){root.hidden=true;current=null;failed=false;},error(message){failed=true;root.dataset.motion='stale';set('voc-error',message);set('voc-state','刷新中断');},draw(s){
  const m=stageModel(s),spec=stageSpecs.find(x=>x.id===m.id);current=m;failed=false;offset=s.demoClock?(s.observedAt-Date.now()/1000):0;
  if(lastStage!==m.id){bars.clear();el('voc-bars').replaceChildren();lastStage=m.id;}
  root.hidden=false;root.dataset.hasBars=String(!!m.bars?.length);root.dataset.motion=m.status;root.dataset.taskId=s.taskId;root.dataset.observedAt=s.observedAt;
  set('voc-updated',(s.demoClock?'演示时间 ':'读取于 ')+new Date(s.observedAt*1000).toLocaleTimeString('zh-CN',{hour12:false}));set('voc-project',s.project);set('voc-phase',m.title??spec?.name??m.id);
  const labels={running:'进行中',waiting:'配额等待',paused:'已暂停',blocked:'待处理',stale:'数据陈旧',complete:'已验收',observed:'状态已读取'};set('voc-state',labels[m.status]??m.status);
  [...root.querySelectorAll('.v-route span')].forEach(x=>x.classList.toggle('active',x.textContent===spec?.group));
  set('voc-error',(s.warnings??[]).join('；'));set('voc-headline',m.headline);set('voc-subtitle',m.subtitle);
  (m.bars??[]).forEach(renderBar);for(const [key,node] of bars)if(key>=(m.bars??[]).length){node.remove();bars.delete(key);}
  el('voc-activity').hidden=!!m.bars?.length||!m.activity;el('voc-activity').querySelector('span').textContent=m.activityText??'处理中';
  el('voc-metrics').replaceChildren(...(m.metrics??[]).map(x=>{const div=document.createElement('div');const a=document.createElement('span'),b=document.createElement('strong');a.textContent=x.label;b.textContent=x.text??`${n(x.value)}${x.unit?' '+x.unit:''}`;div.append(a,b);return div;}));
  el('voc-parallel').hidden=!m.parallel;set('voc-parallel',m.parallel);
  el('voc-wait').hidden=!m.wait;set('voc-wait-reason',m.wait?.reason);time();
  el('voc-quota').hidden=!m.quota;set('voc-quota',m.quota?`剩余 ${n(m.quota.remaining)} / ${n(m.quota.window_total)} 次${m.quota.stale?'（已陈旧）':''}`:'');
  el('voc-checks').replaceChildren(...(m.checks??[]).map(x=>{const d=document.createElement('div');d.className='v-check '+x.state;const mark=document.createElement('b'),txt=document.createElement('span');mark.textContent=x.state==='pass'?'✓':x.state==='fail'?'!':'·';txt.textContent=x.label+(x.value?' · '+x.value:'');d.append(mark,txt);return d;}));
  el('voc-important').hidden=!m.note||!['paused','blocked','stale'].includes(m.status);set('voc-important',m.note);
  set('voc-note',m.note??(m.bars?.length?'比例只针对当前阶段，不代表整项研究完成。':m.activityText));
  el('voc-details').replaceChildren(...[spec?.basis,...(m.details??[]),...(s.sources??[]).map(x=>x.file)].filter(Boolean).map(t=>{const p=document.createElement('p');p.textContent=t;return p;}));
 }};
}
