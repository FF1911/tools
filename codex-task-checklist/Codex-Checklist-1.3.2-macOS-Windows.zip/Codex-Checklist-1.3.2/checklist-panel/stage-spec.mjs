export const stageSpecs=[
 {id:'discover',group:'采集',name:'发现候选',primary:'本轮检索完成量（有可靠任务清单时）',secondary:['去重候选帖','已覆盖社区','当前检索对象'],basis:'已完成检索单元 / 本轮计划检索单元；无计划总量则不显示百分比',source:'检索任务清单、search_runs、posts',motion:'活动指示；候选数量变动高亮'},
 {id:'prescreen',group:'采集',name:'采前预筛',primary:'已评分 / 本轮待评分帖',secondary:['剔除帖','留检帖','未评分保留帖'],basis:'同一预筛输入集合，不以所有候选帖为分母',source:'prescreen_scores.jsonl、prescreen.json',motion:'进度填充；剔除率只作结果，不作为完成率'},
 {id:'collect',group:'采集',name:'采集评论树',primary:'生效名额内已完成帖 / 实际生效名额',secondary:['已采评论','失败或不完整帖','请求配额与等待'],basis:'按社区 min(已完成帖, 生效名额) 求和；扩样后用新名额重算',source:'effective_caps.json、posts、items、pace_state.json',motion:'完成量平滑填充；配额等待用倒计时，完成进度不自增'},
 {id:'screen',group:'语料处理',name:'相关性筛选',primary:'本轮已返回判读条目 / 本轮导出条目',secondary:['相关条目','待返回条目','已入库条目'],basis:'按批次清单与 item_id 去重求交；边采边筛分母会增长',source:'batches/manifest.json、coded、codings（__screen）',motion:'动态分母进度；并行采集单列'},
 {id:'screen_audit',group:'语料处理',name:'筛选复核',primary:'召回率、κ 与各自门槛',secondary:['复核样本覆盖','未过线项','补判或人工决定'],basis:'只对复核覆盖率画条；质量通过依据验收结果，不看文件个数',source:'screen_audit_rounds、screen_gate_options、screen_gate_decision',motion:'质量指标对照；待决定时停止活动动画'},
 {id:'code',group:'语料处理',name:'正式编码',primary:'本轮已返回条目 / 本轮抽样条目',secondary:['核验通过并入库','缺失或需重判','样本目标'],basis:'限定本轮生产批次，不混入初筛、归档或其他任务',source:'sample_size.json、生产 manifest、coded、codings',motion:'返回与核验两条进度，防止结果落盘被当成完成'},
 {id:'blind',group:'语料处理',name:'双盲复核',primary:'A、B 两通道各自完成量 / 本轮盲判样本',secondary:['两通道均完成','待合并条目','失败或缺失块'],basis:'按 blind_round 样本集合分别求交；A 完成不能替代 B',source:'blind_round.json、blind_sample、blind_a/b',motion:'两条独立进度条'},
 {id:'quality',group:'交付',name:'编码一致性',primary:'未达到目标等级的研究问题数',secondary:['一致性结果','各问题证据等级','需补样或重判'],basis:'展示质量判定，不把等级平均成总百分比；变更后旧结果需失效',source:'label_agreement、error_budget、_provenance',motion:'分项等级与阻塞提示，无伪总进度'},
 {id:'deliver',group:'交付',name:'交付前审核',primary:'尚未通过的门禁与审阅项',secondary:['数字契约','HTML 报告','独立审阅与修订'],basis:'门禁、报告检查和审阅分别验收；文件存在不代表可交付',source:'audit_result、report.html、semantic_review、review_response',motion:'逐项勾选；全部有效验收通过才显示完成'}
];
