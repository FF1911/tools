import fs from 'node:fs';
import path from 'node:path';

const uuid=/^[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}$/i;
function records(file){
 const stat=fs.statSync(file);if(!stat.isFile()||stat.size>32*1024*1024)throw Error('记录过大或不可读');
 return fs.readFileSync(file,'utf8').split('\n').flatMap(line=>{try{return[JSON.parse(line)];}catch{return[];}});
}
export function summarize(rows,now=Date.now()){
 let status='unknown',updatedAt=null,latest='',messages=[];
 for(const row of rows){
  const p=row.payload;if(row.type!=='event_msg'||!p)continue;
  if(p.type==='task_started'){status='active';latest='任务已启动';messages=[];updatedAt=row.timestamp;}
  if(p.type==='item_completed'){
   updatedAt=row.timestamp;const i=p.item??{};
   if(i.type==='AgentMessage'){
    const text=(i.content??[]).filter(x=>x.type==='Text').map(x=>x.text).join('\n');
    if(text){latest=text;messages.push({time:row.timestamp,text});}
   }else if(i.type==='CommandExecution'){latest='执行命令'+(i.exit_code!=null?' · 退出码 '+i.exit_code:'');}
  }
  if(p.type==='task_complete'){status='completed';updatedAt=row.timestamp;latest=p.last_agent_message||latest;if(latest&&!messages.some(m=>m.text===latest))messages.push({time:row.timestamp,text:latest});}
  if(['turn_aborted','task_aborted'].includes(p.type)){status='interrupted';updatedAt=row.timestamp;latest='任务已中断';}
 }
 if(status==='active'&&(!updatedAt||now-Date.parse(updatedAt)>120000))status='stale';
 return {status,updatedAt,latest:latest.slice(0,12000),messages:messages.slice(-5).map(m=>({...m,text:m.text.slice(0,12000)}))};
}
export function createBackgroundReader(bindingFile){
 return taskId=>{
  const bindings=JSON.parse(fs.readFileSync(bindingFile,'utf8')),binding=bindings[taskId];
  if(!binding)return{taskId,bound:false,tasks:[]};
  const parent=records(binding.transcript),agents=new Map();
  for(const row of parent){
   const i=row.type==='event_msg'&&row.payload?.type==='item_completed'?row.payload.item:null;
   if(i?.type==='SubAgentActivity'&&uuid.test(i.agent_thread_id)&&i.agent_thread_id!==binding.threadId)
    agents.set(i.agent_thread_id,{threadId:i.agent_thread_id,agentPath:i.agent_path??''});
  }
  const dir=path.dirname(binding.transcript),names=fs.readdirSync(dir);
  const tasks=[...agents.values()].map(a=>{
   const name=names.find(n=>n.endsWith('-'+a.threadId+'.jsonl'));
   const title=binding.titles?.[a.agentPath]||a.agentPath.split('/').pop()||'后台任务';
   if(!name)return{...a,title,status:'unavailable',latest:'未找到本机任务记录',messages:[]};
   try{return{...a,title,...summarize(records(path.join(dir,name)))};}catch{return{...a,title,status:'unavailable',latest:'任务记录暂时无法读取',messages:[]};}
  });
  return{taskId,bound:true,observedAt:new Date().toISOString(),tasks};
 };
}
