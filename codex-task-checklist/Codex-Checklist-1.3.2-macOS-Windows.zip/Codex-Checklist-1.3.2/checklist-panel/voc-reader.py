"""Read-only VOC snapshot. Never starts/imports a driver, opens a browser or emits notifications."""
import json,sqlite3,sys,time,re,math,hashlib,tempfile,shutil
from datetime import datetime
from pathlib import Path
from voc_processing import processing_snapshot

def copy_read_snapshot(db, destination):
 # A read-only WAL database may need to create -shm even after its writer exits.
 # Copy a stable DB/WAL pair to private scratch space; never create source sidecars.
 paths=[db,Path(str(db)+'-wal')]
 def stamps():
  out=[]
  for p in paths:
   try:
    s=p.stat();out.append((s.st_ino,s.st_size,s.st_mtime_ns,s.st_ctime_ns))
   except FileNotFoundError:out.append(None)
  return out
 for attempt in range(3):
  before=stamps()
  if before[0] is None:raise FileNotFoundError('数据库文件不存在')
  if sum(s[1] for s in before if s)>256*1024*1024:raise ValueError('只读快照超过 256 MB 上限')
  try:
   for p,stat in zip(paths,before):
    target=destination/p.name
    if target.exists():target.unlink()
    if stat is not None:shutil.copyfile(p,target)
  except FileNotFoundError:continue
  if before==stamps():return destination/db.name
 raise RuntimeError('数据库正在变化，稍后重试只读快照')

def snapshot(config):
 config=Path(config).resolve();root=config.parent.parent;now=time.time();warnings=[];sources=[]
 def load(p):
  if not p.exists():return None
  try:
   if p.stat().st_size>2_000_000:raise ValueError('文件超过读取上限')
   v=json.loads(p.read_text());sources.append({'file':str(p.relative_to(root)), 'updatedAt':p.stat().st_mtime});return v
  except Exception as e:warnings.append(p.name+' 无法读取：'+str(e));return None
 cfg=load(config)
 if not isinstance(cfg,dict):raise ValueError('配置无法读取')
 db=(config.parent/cfg['db']).resolve();db.relative_to(root)
 pace=load(db.parent/'pace_state.json');caps=load(db.parent/'effective_caps.json')
 state=load(db.parent/'.autonomy'/hashlib.sha256(str(db).encode()).hexdigest()[:16]/'state.json')
 execution=None
 if isinstance(state,dict) and state.get('config')==str(config):
  execution={k:state.get(k) for k in ['status','paused','reason','updated_at']}
 target=None
 if isinstance(caps,dict) and isinstance(caps.get('per_community'),dict):
  vals=list(caps['per_community'].values())
  if vals and all(isinstance(v,int) and not isinstance(v,bool) and v>=0 for v in vals):target=sum(vals)
 run_start=None;target_current=False
 log=db.parent/'acquire.log';phase='尚无采集阶段记录';marker=None
 if log.exists():
  with log.open('rb') as f:f.seek(max(0,log.stat().st_size-1_000_000));text=f.read().decode(errors='replace')
  inits=list(re.finditer(r'^\[[^\]]+\]\s*init\s*$',text,re.M))
  text=text[inits[-1].start():] if inits else text
  if inits:
   try:run_start=datetime.fromisoformat(re.search(r'^\[([^\]]+)\]',text).group(1).replace('Z','+00:00')).timestamp()
   except (ValueError,AttributeError):pass
  for line in text.splitlines():
   if '] discover' in line:phase='发现候选'
   if '] collect ' in line:phase='采集评论树'
   m=re.search(r'\]\s*(ACQUIRE_(?:DONE|ABORTED|PENDING\S*))',line)
   if m:marker=m.group(1);phase='采集已结束（不代表报告完成）' if marker=='ACQUIRE_DONE' else '采集停止点：'+marker
  sources.append({'file':str(log.relative_to(root)),'updatedAt':log.stat().st_mtime})
 target_current=target is not None and run_start is not None and (db.parent/'effective_caps.json').stat().st_mtime>=run_start
 collection=None;processing=None;pipeline=None;c=None;scratch=None
 try:
  try:
   c=sqlite3.connect(db.as_uri()+'?mode=ro',uri=True,timeout=1)
   c.execute('SELECT name FROM sqlite_master LIMIT 1').fetchone()
  except sqlite3.OperationalError as e:
   if c is not None:c.close();c=None
   if 'unable to open database file' not in str(e):raise
   scratch=tempfile.TemporaryDirectory(prefix='voc-panel-read-')
   copied=copy_read_snapshot(db,Path(scratch.name))
   # macOS SQLite may refuse mode=ro on a WAL-mode file after its sidecars
   # disappear, even in a writable directory. Only the private copy may create
   # WAL/SHM files. query_only below prohibits data writes before any query.
   c=sqlite3.connect(copied.as_uri()+'?mode=rw',uri=True,timeout=1)
  c.execute('PRAGMA query_only=ON');c.execute('BEGIN')
  counts=dict(c.execute('SELECT tree_status,COUNT(*) FROM posts GROUP BY tree_status'))
  items=c.execute('SELECT COUNT(*),SUM(CASE WHEN is_top_post=0 THEN 1 ELSE 0 END) FROM items').fetchone()
  tasks=[{'task':t,'items':n,'applicable':a or 0} for t,n,a in c.execute('SELECT task,COUNT(*),SUM(CASE WHEN applicable=1 THEN 1 ELSE 0 END) FROM codings GROUP BY task')]
  completed_within_target=None
  if target_current:
   try:
    by_com=dict(c.execute("SELECT community,COUNT(*) FROM posts WHERE tree_status='completed' GROUP BY community"))
    completed_within_target=sum(min(by_com.get(k,0),v) for k,v in caps['per_community'].items())
   except sqlite3.Error:target_current=False
  collection={'targetCurrent':target_current,'completedWithinTarget':completed_within_target,'candidates':sum(counts.values()),'completed':counts.get('completed',0),'queued':counts.get('queued',0),'inflight':sum(counts.get(k,0) for k in ['in_progress','partial','interrupted']),'failed':counts.get('failed',0),'prescreenedOut':counts.get('prescreened_out',0),'target':target,'targetSource':'effective_caps.json' if target is not None else None,'statuses':counts}
  processing={'items':items[0],'comments':items[1] or 0,'tasks':tasks}
  try:pipeline=processing_snapshot(root,cfg,c)
  except Exception as e:warnings.append('语料进度暂时无法读取：'+str(e))
  c.close();sources.append({'file':str(db.relative_to(root)),'readAt':now})
 except Exception as e:warnings.append('数据库暂时无法读取：'+str(e))
 finally:
  if c is not None:c.close()
  if scratch is not None:scratch.cleanup()
 analysis=root/'analysis';batches=[]
 if analysis.exists():
  for d in sorted(analysis.iterdir()):
   if not d.is_dir() or d.is_symlink():continue
   exported=list((d/'batches').glob('batch_*.json'));results=list((d/'coded').glob('coded_*.json'))
   # File counts are not accepted/validated item counts.
   batches.append({'task':d.name,'exportedFiles':len(exported),'resultFiles':len(results)})
 if processing is not None:processing['batches']=batches
 quota=None
 if isinstance(pace,dict):
  quota={k:pace.get(k) for k in ['remaining','window_total','reset_at','sleeping','wake_at','reason','updated_at']}
  for key in ['remaining','window_total','reset_at','wake_at','updated_at']:
   v=quota[key]
   if v is not None and (isinstance(v,bool) or not isinstance(v,(int,float)) or not math.isfinite(v) or v<0):
    quota[key]=None;warnings.append('配额字段 '+key+' 无效')
  age=now-(quota.get('updated_at') or 0);quota['ageSeconds']=max(0,int(age));quota['stale']=age>600
  quota['waitSeconds']=max(0,int((quota.get('wake_at') or now)-now)) if pace.get('sleeping') else 0
 return {'schemaVersion':1,'skill':'voc-deepdive','project':root.name,'observedAt':now,'phase':phase,'marker':marker,'execution':execution,'quota':quota,'collection':collection,'processing':processing,'pipeline':pipeline,'warnings':warnings,'sources':sources}
if __name__=='__main__':
 try:print(json.dumps(snapshot(sys.argv[1]),ensure_ascii=False))
 except Exception as e:print(json.dumps({'error':str(e)},ensure_ascii=False));sys.exit(1)
