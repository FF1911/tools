import {mountBackground,createBackgroundController} from './background-view.mjs';
import {App} from '@modelcontextprotocol/ext-apps';
import {mountVoc,createVocController} from './voc-view.mjs';
import {mountChecklist,markSynced} from './view.mjs';
import {createPanelController} from './controller.mjs';
import {createSelectionController} from './selection-controller.mjs';
const app=new App({name:'清单面板 · 双卡片',version:'0.3.1'},{},{autoResize:true});
const $=id=>document.getElementById(id),chooser=$('choose'),card=$('checklist'),connection=$('connection');
const draw=mountChecklist(document);
const background=createBackgroundController({draw:mountBackground(document),fetchState:async taskId=>{const r=await app.callServerTool({name:'read_background_tasks',arguments:{taskId}});if(r.isError)throw Error('background read failed');return r.structuredContent;}});

const voc=createVocController({view:mountVoc(document),fetchState:async taskId=>{const r=await app.callServerTool({name:'read_voc_progress',arguments:{taskId}});if(r.isError)throw Error('progress read failed');return r.structuredContent;}});
let vocTimer;
async function vocTick(){clearTimeout(vocTimer);if(!ready||stopped||document.visibilityState==='hidden')return;await Promise.allSettled([voc.refresh(),background.refresh()]);if(!stopped)vocTimer=setTimeout(vocTick,5000);}
function inspectResult(result){const p=result?._meta?.['checklistPanel/identityProbe'];if(p){$('identity-probe').textContent=p.candidates.length?'会话标识候选：'+p.candidates.map(c=>c.key+' · '+c.fingerprint).join('；'):'本次请求未携带会话标识。';}return result;}

let ready=false,stopped=false,busy=false,timer,contextTimer;
const selectionStatus=$('selection-status');
const panel=createPanelController({
 onSynced:s=>markSynced(document,s),
 fetchState:async taskId=>inspectResult(await app.callServerTool({name:'read_panel_checklist',arguments:{taskId}})),
 draw:s=>{card.hidden=false;draw(s);const option=Array.from(chooser.options).find(o=>o.value===s.taskId);if(option)option.textContent=`${s.title} · ${s.plan.filter(x=>x.status==='completed').length}/${s.plan.length} · ${s.taskId.slice(0,8)}`;$('version').textContent=`版本 ${s.revision} · 保存于 ${new Date(s.updatedAt).toLocaleString()}`;$('identity').textContent=s.taskId;},
 onSelection:id=>{background.select(id);voc.select(id);void vocTick();card.hidden=true;$('empty').hidden=!!id;ensureOption(id);chooser.value=id??'';},
 onStatus:message=>{connection.textContent=message;connection.hidden=!message;},
 persist:async()=>{}
});
function ensureOption(id){if(id&&!Array.from(chooser.options).some(o=>o.value===id)){const o=document.createElement('option');o.value=id;o.textContent='已保存的选择 · '+id.slice(0,8);chooser.append(o);}}
function list(data){
 if(!Array.isArray(data?.tasks))return;
 const selected=panel.selected??'';chooser.replaceChildren(new Option('自动选择本会话任务',''));
 for(const t of data.tasks){const o=new Option(`${t.title} · ${t.completed}/${t.total} · ${t.taskId.slice(0,8)}`,t.taskId);chooser.append(o);}
 ensureOption(selected);chooser.value=selected;
 $('list-note').textContent=data.unreadable?`${data.unreadable} 份清单暂时无法读取，未自动替换。`:'';
}
async function call(name,args={}){const r=inspectResult(await app.callServerTool({name,arguments:args}));if(r.isError)throw Error(r.structuredContent?.error?.message||'请求失败');return r.structuredContent;}
const selection=createSelectionController({
 resolve:()=>call('resolve_panel_context'),
 save:(taskId,expectedRevision,expectedConversationKey)=>call('select_panel_checklist',{taskId,expectedRevision,expectedConversationKey}),
 apply:async context=>{
  const messages={saved_selection:'已恢复本会话上次选择',recent_active:'已自动加载本会话最近的未完成清单',recent_completed:'已自动加载本会话最近的已完成清单',no_association:'本会话尚未关联清单；新任务将自动关联，旧任务可手动选择一次。',missing_identity:'未取得会话标识，请手动选择；不会自动加载其他会话的清单。',selected_unavailable:'本会话原先选择的清单暂时无法读取，请检查或重新选择。'};
  selectionStatus.textContent=messages[context.reason]||'';
  await panel.select(context.taskId,{save:false});
 },
 onStatus:message=>{if(message)selectionStatus.textContent=message;}
});
async function contextTick(){clearTimeout(contextTimer);if(!ready||stopped||document.visibilityState==='hidden')return;await selection.refresh();if(!stopped)contextTimer=setTimeout(contextTick,5000);}
async function tick(){clearTimeout(timer);if(!ready||stopped||busy||document.visibilityState==='hidden')return;busy=true;try{await panel.refresh();}finally{busy=false;if(!stopped)timer=setTimeout(tick,panel.delay);}}
// Entry results populate choices only. Resolve the chat through a fresh server
// call after connect, so a restored historical tool result cannot select a task.
app.ontoolresult=result=>{list(inspectResult(result).structuredContent);};
chooser.addEventListener('change',async()=>{await selection.choose(chooser.value||null);void tick();});
$('refresh-list').addEventListener('click',async()=>{try{list(await call('list_panel_checklists'));await selection.refresh();await panel.refresh();}catch{connection.hidden=false;connection.textContent='列表刷新失败，请稍后重试。';}});
try{await app.connect();ready=true;list(await call('list_panel_checklists'));await contextTick();void tick();void vocTick();}catch{connection.textContent='面板连接失败，请关闭后重新打开。';connection.hidden=false;}
document.addEventListener('visibilitychange',()=>{if(document.visibilityState==='visible'){void contextTick();void tick();void vocTick();}else{clearTimeout(timer);clearTimeout(vocTimer);clearTimeout(contextTimer);}});
window.addEventListener('pagehide',()=>{stopped=true;clearTimeout(timer);clearTimeout(vocTimer);clearTimeout(contextTimer);});
window.addEventListener('pageshow',()=>{stopped=false;void contextTick();void tick();void vocTick();});
