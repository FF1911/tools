// Server-backed selection; widgetState from older versions is deliberately not
// used as a fallback because it lacks a verified chat identity.
export function createSelectionController({resolve,save,apply,onStatus}){
 let context=null,generation=0,chain=Promise.resolve(),pending=0;
 async function accept(next){
  const changed=context?.conversationKey!==next.conversationKey||context?.taskId!==next.taskId||context?.mode!==next.mode;
  context=next;
  if(changed)await apply(next);
 }
 return{
  async refresh(){
   if(pending)return;
   const token=++generation;
   try{const next=await resolve();if(token!==generation)return;await accept(next);}
   catch(e){if(token===generation)onStatus('会话选择暂时无法恢复：'+e.message);}
  },
  choose(taskId){
   const token=++generation,key=context?.conversationKey;pending++;
   const work=chain.then(async()=>{
    if(token!==generation)return;
    if(!context?.identified){await apply({identified:false,conversationKey:null,taskId,mode:'manual',reason:'temporary',selectionRevision:0});onStatus('当前宿主未提供会话标识，本次选择不能跨关闭恢复。');return;}
    if(context.conversationKey!==key)return;
    try{
     const next=await save(taskId,context.selectionRevision,key);
     if(next.conversationKey!==key)throw Error('会话已经切换');
     if(token!==generation){if(context?.conversationKey===key)context={...context,selectionRevision:next.selectionRevision};return;}
     await accept(next);onStatus(next.conflict?'选择已在另一处更新，已恢复最新选择；如需更改请重新选择。':'');
    }catch(e){if(token===generation)onStatus('选择未保存：'+e.message);}
   }).finally(()=>{pending--;});
   chain=work.catch(()=>{});return work;
  },
  invalidate(){generation++;context=null;},
  get context(){return context;},get pending(){return pending;}
 };
}
