"""Bounded read-only progress adapter. No driver execution or project writes."""
import hashlib,json,re,sqlite3
from pathlib import Path
from voc_audit_math import screen_audit

def iid(row):
 if not isinstance(row,dict):return None
 if isinstance(row.get('item_id'),str):return row['item_id']
 if row.get('post_id') and row.get('comment_id') is not None:return str(row['post_id'])+':'+str(row['comment_id'])
 return None

def app(row):
 v=row.get('applicable')
 if v is True or v==1 or v in ('true','1'):return 1
 if v is False or v==0 or v in ('false','0'):return 0
 return None

def processing_snapshot(root,cfg,conn):
 root=Path(root).resolve();warnings=[];read_bytes=0;artifacts=[]
 task=(cfg.get('early_screen') or {}).get('task')
 if not task:
  ts={q.get('task') for q in cfg.get('research_questions',[]) if q.get('task')}
  if len(ts)==1:task=next(iter(ts))
 if not isinstance(task,str) or not re.fullmatch(r'[\w.-]+',task):return None
 # analysis_dir is relative to the project, as in drive_judge's project layout.
 analysis=Path(cfg.get('analysis_dir') or 'analysis')
 if not analysis.is_absolute():analysis=root/analysis
 directory=(analysis/task).resolve()
 try:directory.relative_to(root)
 except ValueError:return {'task':task,'warnings':['分析目录不在绑定项目内，未读取']}
 def local(path):
  p=Path(path).resolve();p.relative_to(directory);return p
 def load(path,required=False):
  nonlocal read_bytes
  try:
   p=local(path)
   if not p.exists():
    if required:warnings.append(p.name+' 缺失')
    return None
   before=p.stat();read_bytes+=before.st_size
   if before.st_size>8_000_000 or read_bytes>96_000_000:raise ValueError('超过进度读取上限')
   data=json.loads(p.read_text());after=p.stat()
   if (before.st_mtime_ns,before.st_size)!=(after.st_mtime_ns,after.st_size):raise ValueError('正在更新，等待下一次读取')
   artifacts.append((p,after.st_mtime_ns,after.st_size))
   return data
  except (OSError,ValueError) as e:warnings.append(Path(path).name+'：'+str(e));return None
 def rows(path,required=False):
  v=load(path,required)
  if v is None:return None
  if isinstance(v,dict):v=v.get('items',v.get('results',v.get('rows')))
  if not isinstance(v,list):warnings.append(Path(path).name+' 不是条目列表');return None
  return [r for r in v if isinstance(r,dict)]
 def byid(rs):return {iid(r):r for r in rs or [] if iid(r)}
 def dbrows(name):
  if conn is None:return None
  try:
   return {i:{'applicable':a,'primary_label':lab} for i,a,lab in conn.execute('SELECT item_id,applicable,primary_label FROM codings WHERE task=?',(name,))}
  except sqlite3.Error:return None
 database={k:dbrows(task+suffix) for k,suffix in [('screen','__screen'),('code',''),('screen_audit','__audit'),('confirm','__audit2')]}
 def progress(manifest,base,force=None):
  groups={k:{} for k in ('screen','code','screen_audit','confirm')}
  if not isinstance(manifest,dict) or manifest.get('task')!=task:return {}
  runs=manifest.get('runs') or [manifest]
  # A fresh screening round after production supersedes prior production batches.
  start=0;seen_code=False
  for ix,r in enumerate(runs):
   if r.get('screen') and not r.get('audit'):
    if seen_code:start=ix;seen_code=False
   elif not r.get('audit'):seen_code=True
  if start:warnings.append('编码后出现新的初筛批次，暂不沿用此前编码计数；当前轮归属需核对')
  for run in runs[start:]:
   kind=force or ('confirm' if run.get('frame')=='audit-confirm' else 'screen_audit' if run.get('audit') or run.get('frame')=='screen-audit' else 'screen' if run.get('screen') else 'code')
   for b in run.get('batches',[]):
    name=Path(b.get('file','')).name
    match=re.fullmatch(r'batch_(\d+)\.json',name)
    if match:groups[kind][int(match[1])]=name
  out={}
  for kind,files in groups.items():
   if not files:continue
   expected={};latest={};invalid=0;unknown=False
   for _,name in sorted(files.items()):
    inp=base/'batches'/name;data=rows(inp,True)
    if data is None:unknown=True;continue
    wants=byid(data)
    if len(wants)!=len(data):unknown=True;warnings.append(name+' 条目标识缺失或重复')
    expected.update(wants)
    # A newly exported rejudging batch invalidates previous results for its IDs.
    for key in wants:latest.pop(key,None)
    result=base/'coded'/name.replace('batch_','coded_')
    got=rows(result)
    if got is None:continue
    if result.stat().st_mtime_ns<inp.stat().st_mtime_ns:
     warnings.append(result.name+' 早于对应批次，未计入');continue
    seen=set()
    for r in got:
     key=iid(r)
     row_task=task+{'screen':'__screen','screen_audit':'__audit','confirm':'__audit2','code':''}[kind]
     if key not in wants or key in seen or app(r) is None or (r.get('task') and r['task'] not in (task,row_task)):
      invalid+=1;continue
     seen.add(key);latest[key]=r
   db=database[kind]
   agreed=None if db is None else sum(1 for key,r in latest.items() if key in db and app(r)==app(db[key]) and (kind!='code' or r.get('primary_label')==db[key].get('primary_label')))
   out[kind]={'total':None if unknown else len(expected),'returned':len(latest),'pending':None if unknown else len(expected)-len(latest),'related':sum(app(r)==1 for r in latest.values()),'ingested':agreed,'invalid':invalid,'batchCount':len(files),'scope':'当前轮累计导出条目，按 ID 去重；重判使用最新批次'}
  return out
 manifest=load(directory/'batches/manifest.json')
 stages=progress(manifest,directory)
 for sub,kind in [('screen_audit','screen_audit'),('audit_confirm','confirm')]:
  m=load(directory/sub/'batches/manifest.json')
  if m:stages.update(progress(m,directory/sub,kind))
 # Recompute screening audit from the same read transaction, using the skill's pure math.
 audit=None
 if conn is not None and database['screen'] and database['screen_audit']:
  try:
   r=screen_audit(conn,task)
   audit={k:r.get(k) for k in ['recall','kappa','recall_ci','min_recall','min_kappa','verdict','uncovered_screen_n','confirm','advice']}
  except (SystemExit,Exception) as e:audit={'verdict':'待核实','reason':str(e)}
 # Current production signature: same algorithm as judge_pipeline.codings_sig.
 sig=None
 if database['code'] is not None:
  h=hashlib.sha1();db=database['code']
  for i,r in sorted(db.items()):h.update(f"{i}|{r['applicable']}|{r['primary_label']}\n".encode())
  sig={'n':len(db),'n_app':sum(r['applicable'] or 0 for r in db.values()),'sig':h.hexdigest()[:16]}
 def freshness(prov):
  if not isinstance(prov,dict) or sig is None:return 'unknown'
  return 'current' if prov.get('task')==task and prov.get('codings')==sig else 'stale'
 blind=None;blind_stamp=0
 # Official tasks may keep blind files in the task root or its blind/ directory.
 manifests=[]
 for bd in (directory,directory/'blind'):
  m=load(bd/'blind_round.json')
  if isinstance(m,dict) and m.get('task')==task:manifests.append((bd,m,(bd/'blind_round.json').stat().st_mtime_ns))
 if manifests:
  bd,bm,blind_stamp=max(manifests,key=lambda x:x[2]);active=[r for r in bm.get('rounds',[]) if not r.get('superseded')]
  wants=set();got={'a':set(),'b':set()};unknown=False;bad={'a':0,'b':0};latest_result=0
  for rnd in active:
   sample=rnd.get('sample')
   if sample:
    sp=Path(sample);sp=sp if sp.is_absolute() else bd/sp
    sr=rows(sp,True)
    if sr is None:unknown=True
    else:wants.update(byid(sr))
   for chunk in rnd.get('chunks',[]):
    if not isinstance(chunk,int) or isinstance(chunk,bool):unknown=True;continue
    inp=bd/f'blind_input_{chunk:02d}.json';ir=rows(inp,True)
    if ir is None:unknown=True;continue
    ids=set(byid(ir));wants.update(ids)
    for ch in ('a','b'):
     rp=bd/f'blind_{ch}_{chunk:02d}.json';rs=rows(rp)
     if rs is None:continue
     if rp.stat().st_mtime_ns<inp.stat().st_mtime_ns:bad[ch]+=1;continue
     valid={iid(r) for r in rs if app(r) is not None};got[ch].update(valid&ids)
     if valid!=ids or len(valid)!=len(rs):bad[ch]+=1
     latest_result=max(latest_result,rp.stat().st_mtime_ns)
   for ch in ('a','b'):
    for f in (rnd.get('reuse_files') or {}).get(ch,[]):
     fp=Path(f);fp=fp if fp.is_absolute() else bd/fp
     rs=rows(fp,True)
     if rs is None:bad[ch]+=1;continue
     got[ch].update(iid(r) for r in rs if iid(r) and app(r) is not None)
  got={ch:ids&wants for ch,ids in got.items()};common=got['a']&got['b'];merged=common.copy()
  for ch in ('a','b'):
   mp=bd/f'blind_{ch}.json';rs=rows(mp)
   if rs is None or mp.stat().st_mtime_ns<latest_result:merged=set()
   else:merged&=set(byid(rs))
   if mp.exists():blind_stamp=max(blind_stamp,mp.stat().st_mtime_ns)
  blind_stamp=max(blind_stamp,latest_result)
  blind={'total':None if unknown else len(wants),'a':len(got['a']),'b':len(got['b']),'both':len(common),'merged':len(merged),'pendingMerge':len(common-merged),'invalidChunks':bad,'rounds':len(active)}
 grades=load(directory/'label_agreement.json');meta=load(directory/'label_agreement.meta.json')
 quality=None
 if isinstance(grades,list):
  fresh=freshness((meta or {}).get('_provenance'));bycode={r.get('code'):r for r in grades if isinstance(r,dict)}
  if blind_stamp>(directory/'label_agreement.json').stat().st_mtime_ns:fresh='stale'
  questions=[];rank={'A':4,'B':3,'C':2,'D':1}
  for q in cfg.get('research_questions',[]):
   if q.get('task')!=task:continue
   codes=q.get('codes') or [];target=q.get('min_grade','B');observed=[bycode.get(x,{}).get('grade') for x in codes]
   passed=bool(observed) and all(rank.get(g,0)>=rank.get(target,3) for g in observed)
   questions.append({'label':q.get('question') or q.get('id'),'target':target,'grades':observed,'state':'unknown' if fresh!='current' else 'pass' if passed else 'fail'})
  quality={'freshness':fresh,'questions':questions,'codes':[{'code':r.get('code'),'grade':r.get('grade'),'f1':r.get('f1'),'blind_n':r.get('blind_n')} for r in grades if isinstance(r,dict)],'gradeBasis':(meta or {}).get('grade_basis')}
 gate=load(directory/'audit_result.json');delivery=None
 if isinstance(gate,dict):
  fresh=freshness(gate.get('_provenance'))
  deps=[directory/'label_agreement.json',directory/'label_agreement.meta.json',directory/'numbers_manifest.json']
  if (quality and quality['freshness']!='current') or any(p.exists() and p.stat().st_mtime_ns>(directory/'audit_result.json').stat().st_mtime_ns for p in deps):fresh='stale'
  delivery={'freshness':fresh,'status':gate.get('status'),'gates':gate.get('gates',[]),'fail':gate.get('n_fail'),'warn':gate.get('n_warn')}
 driver=load(directory/'.drive/state.json')
 state=None
 if isinstance(driver,dict):
  stage=driver.get('stage');status=driver.get('status')
  state={'stage':stage,'status':status,'reason':((driver.get('human') or driver.get('stuck') or {}).get('reason'))}
 follow=load(directory/'.drive/follow_screen.json')
 # Refuse a mixed filesystem snapshot if a manifest/result was replaced during reading.
 changed=False
 for path,stamp,size in artifacts:
  try:
   st=path.stat()
   if (st.st_mtime_ns,st.st_size)!=(stamp,size):changed=True;break
  except OSError:changed=True;break
 if changed:
  return {'task':task,'warnings':['判读文件正在更新，等待下一次一致快照'],'consistent':False}
 return {'task':task,'consistent':True,'stages':stages,'audit':audit,'blind':blind,'quality':quality,'delivery':delivery,'driver':state,'followScreen':follow,'warnings':list(dict.fromkeys(warnings))[:12]}
