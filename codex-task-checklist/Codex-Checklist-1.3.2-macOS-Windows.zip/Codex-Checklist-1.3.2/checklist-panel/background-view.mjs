const statuses={active:'进行中 · 最近有活动',completed:'已完成',interrupted:'已中断',stale:'等待更新',unknown:'状态未知',unavailable:'暂不可读'};
export function mountBackground(document){
 const root=document.getElementById('background-panel'),nodes=new Map();let selected=null;
 return data=>{
  if(selected!==data?.taskId){nodes.clear();root.replaceChildren();selected=data?.taskId;}
  root.hidden=!data?.bound;if(root.hidden)return;
  let heading=root.querySelector('h2');if(!heading){heading=document.createElement('h2');heading.textContent='后台任务';root.append(heading);}
  let info=root.querySelector('.bg-info');if(!info){info=document.createElement('p');info.className='bg-info muted';root.append(info);}
  info.textContent=data.error?'刷新失败，保留上次记录；状态可能已变化。':`${data.tasks.length} 个任务 · 点击展开进展和结果 · 每 5 秒刷新`;
  const ids=new Set(data.tasks.map(t=>t.threadId));for(const[id,node]of nodes)if(!ids.has(id)){node.remove();nodes.delete(id);}
  for(const t of data.tasks){
   let node=nodes.get(t.threadId);
   if(!node){node=document.createElement('details');node.className='bg-task';const summary=document.createElement('summary');summary.append(document.createElement('strong'),document.createElement('span'));node.append(summary);const body=document.createElement('div');body.className='bg-body';node.append(body);nodes.set(t.threadId,node);root.append(node);}
   node.querySelector('strong').textContent=t.title;node.querySelector('summary span').textContent=statuses[t.status]||'状态未知';
   const body=node.querySelector('.bg-body');body.replaceChildren();const stamp=document.createElement('p');stamp.className='muted';stamp.textContent=t.updatedAt?'最近记录：'+new Date(t.updatedAt).toLocaleString():'尚无时间记录';body.append(stamp);
   const latest=document.createElement('p');latest.className='bg-latest';latest.textContent=t.latest||'暂无进展记录';body.append(latest);
   if(t.messages?.length>1){const history=document.createElement('details'),label=document.createElement('summary');label.textContent='近期进展记录';history.append(label);for(const m of t.messages.slice(0,-1)){const p=document.createElement('p');p.textContent=m.text;history.append(p);}body.append(history);}
  }
  let note=root.querySelector('.bg-note');if(!note){note=document.createElement('p');note.className='bg-note muted';root.append(note);}note.textContent='来自本机任务记录；等待更新不等于已停止，完成记录不替代主会话验收。';
 };
}
export function createBackgroundController({fetchState,draw}){
 let selected=null,generation=0,last=null;
 return{select(id){selected=id;generation++;last=null;draw(null);},async refresh(){if(!selected)return;const id=selected,g=generation;try{const s=await fetchState(id);if(g===generation&&s.taskId===id){last=s;draw(s);}}catch{if(g===generation)draw(last?{...last,error:true}:{taskId:id,bound:true,tasks:[],error:true});}}};
}
