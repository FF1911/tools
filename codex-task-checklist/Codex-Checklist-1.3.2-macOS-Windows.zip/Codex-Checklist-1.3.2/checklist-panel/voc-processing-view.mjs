const n=x=>typeof x==='number'&&Number.isFinite(x)?x.toLocaleString('zh-CN'):'—';
const stageIds={全库语义初筛:'screen',初筛入库:'screen',初筛验收:'screen_audit',初筛验收未过线:'screen_audit',初筛二次确认:'screen_audit',样本量:'code',导出:'code',生产判读:'code',入库登记:'code','盲判结果 a/b':'blind','一致性/等级':'quality',发布门禁:'deliver',报告:'deliver'};
export function processingModel(s,base){
 const p=s.pipeline;if(!p)return base;
 if(p.consistent===false)return {...base,status:'stale',activity:false,wait:null,note:p.warnings?.join('；')};
 const d=p.driver,screen=p.stages?.screen;
 let id=d?.status==='done'?'deliver':stageIds[d?.stage];
 // Acquisition retains priority until its real terminal marker; no guesses from filenames.
 if(s.marker!=='ACQUIRE_DONE'&&s.phase==='采集评论树'){
  if(screen){base.bars.push({label:'并行初筛 · 已返回',done:screen.returned,total:screen.total,unit:'条',note:'采集继续时分母会增长'});base.parallel=`初筛：相关 ${n(screen.related)} 条 · 待返回 ${n(screen.pending)} 条 · 已入库 ${n(screen.ingested)} 条`;}
  base.details.push(...(p.warnings??[]));return base;
 }
 if(!id&&s.marker==='ACQUIRE_DONE')id='screen';
 if(!id)return base;
 const paused=s.execution?.paused===true||s.execution?.status==='paused';
 const blocked=['waiting_human','stuck'].includes(d?.status);
 const m={id,status:paused?'paused':blocked?'blocked':'observed',headline:'等待阶段数据',subtitle:'按已保存的本轮产物读取；数量完成与质量验收分别显示。',metrics:[],bars:[],checks:[],activity:false,wait:null,quota:null,note:paused?'用户已暂停任务，保留已保存进度。':d?.reason??null,details:[`判读任务：${p.task}`,`驱动阶段：${d?.stage??'尚未启动判读驱动'}`,...(p.warnings??[])]};
 if(id==='screen'||id==='code'){
  const r=p.stages?.[id];m.headline=`${n(r?.returned)} 条${id==='screen'?'初筛':'编码'}已返回`;
  m.bars=[{label:'本轮已返回',done:r?.returned,total:r?.total,unit:'条'}];
  if(id==='code')m.bars.push({label:'已入库且判定一致',done:r?.ingested,total:r?.total,unit:'条',note:'不等同于质量门禁通过'});
  m.metrics=[{label:'待返回',value:r?.pending,unit:'条'},{label:'判为相关',value:r?.related,unit:'条'},{label:id==='screen'?'已入库且判定一致':'异常返回',value:id==='screen'?r?.ingested:r?.invalid,unit:'条'}];
  if(r?.invalid)m.details.push(`发现 ${r.invalid} 条重复、越界或格式异常的返回，未计入有效完成量。`);
  m.details.push(r?.scope??'尚无本轮批次清单');
 }else if(id==='screen_audit'){
  const a=p.audit,r=p.stages?.screen_audit;m.headline=a?.verdict??'等待复核结果';
  m.metrics=[{label:'召回率 / 门槛',text:`${n(a?.recall)} / ${n(a?.min_recall??.95)}`},{label:'κ / 门槛',text:`${n(a?.kappa)} / ${n(a?.min_kappa??.8)}`},{label:'新增未验收',value:a?.uncovered_screen_n,unit:'条'}];
  m.bars=[{label:'复核样本返回',done:r?.returned,total:r?.total,unit:'条'}];
  m.details.push(...(a?.advice??[]),...(a?.reason?[a.reason]:[]));
  if(a?.verdict==='不通过')m.status='blocked';if(a?.verdict==='验收过期')m.status='stale';
 }else if(id==='blind'){
  const b=p.blind;m.headline=`${n(b?.both)} 条已由双通道返回`;
  m.bars=['a','b'].map(ch=>({label:`通道 ${ch.toUpperCase()} 已返回`,done:b?.[ch],total:b?.total,unit:'条'}));
  m.metrics=[{label:'待合并',value:b?.pendingMerge,unit:'条'},{label:'已合并覆盖',value:b?.merged,unit:'条'},{label:'异常结果块',text:b?`${b.invalidChunks.a} / ${b.invalidChunks.b}`:'—'}];
  m.details.push('仅统计未作废轮次及登记的复用结果；按本轮样本 ID 求交。');
 }else if(id==='quality'){
  const q=p.quality,qs=q?.questions??[],valid=q?.freshness==='current';
  m.headline=!q?'等待一致性结果':!valid?'一致性结果待更新':`${qs.filter(x=>x.state!=='pass').length} 项研究问题未达目标`;
  m.metrics=[{label:'结果有效性',text:valid?'与当前判读一致':q?.freshness==='stale'?'已过期':'待核实'},{label:'已有等级',value:q?.codes?.filter(x=>x.grade).length,unit:'个码'},{label:'研究问题',value:qs.length,unit:'项'}];
  m.checks=qs.map(x=>({label:x.label,state:x.state,value:`${x.grades.map(g=>g??'待定').join(' / ')} · 目标 ${x.target}`}));
  if(q&&!valid)m.status='stale';else if(qs.some(x=>x.state==='fail'))m.status='blocked';
  m.details.push(...(q?.codes??[]).map(x=>`${x.code}：${x.grade??'待定'}，F1 ${n(x.f1)}，盲判 ${n(x.blind_n)} 条`));
 }else if(id==='deliver'){
  const g=p.delivery,valid=g?.freshness==='current';m.headline=!g?'等待发布门禁':!valid?'门禁结果待更新':`${n(g.fail)} 项未通过 · ${n(g.warn)} 项提醒`;
  m.checks=(g?.gates??[]).map(x=>({label:x.name,state:!valid?'unknown':x.status==='PASS'?'pass':x.status==='FAIL'?'fail':'unknown',value:valid?x.status:'结果待核实'}));
  if(g&&!valid)m.status='stale';else if(g?.fail)m.status='blocked';
  m.note='发布门禁与报告交付分别验收；本面板不根据文件存在宣布研究完成。';
 }
 if(paused){m.status='paused';m.note='用户已暂停任务，保留已保存进度。';}
 return m;
}
