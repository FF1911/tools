import {createHash} from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
const hash=v=>createHash('sha256').update('checklist-panel-session-probe-v1\0'+v).digest('hex').slice(0,20);
// Probe request metadata only. A transport session or process environment is not a chat identity.
export function inspectIdentity(extra={}){
 const meta=extra._meta??{},candidates=[];
 const add=(key,value)=>{if(typeof value==='string'&&value.length>0&&value.length<=4096)candidates.push({key,fingerprint:hash(value)});};
 for(const key of ['openai/session','openai/threadId','openai/thread_id','codexThreadId','codex_thread_id','threadId','thread_id'])add(key,meta[key]);
 let turn=meta['x-codex-turn-metadata'];
 if(typeof turn==='string'){try{turn=JSON.parse(turn);}catch{turn=null;}}
 if(turn&&typeof turn==='object')for(const key of ['thread_id','chatgpt_conversation_id'])add('x-codex-turn-metadata.'+key,turn[key]);
 return {schemaVersion:1,candidates,metadataKeys:Object.keys(meta).sort(),transportSessionPresent:typeof extra.sessionId==='string'};
}
export function probeResult(root,method,extra){
 const probe=inspectIdentity(extra);
 if(fs.existsSync(path.join(root,'diagnostics.enabled'))){
  const file=path.join(root,'session-probe.json');
  try{
   let entries=[];try{entries=JSON.parse(fs.readFileSync(file,'utf8')).entries??[];}catch{}
   const entry={at:new Date().toISOString(),method,...probe};
   const last=entries.at(-1);
   if(method==='open_checklist_panel'||!last||last.method!==method||JSON.stringify(last.candidates)!==JSON.stringify(probe.candidates)||JSON.stringify(last.metadataKeys)!==JSON.stringify(probe.metadataKeys)){
    entries.push(entry);const tmp=file+'.'+process.pid+'.tmp';fs.writeFileSync(tmp,JSON.stringify({entries:entries.slice(-80)},null,2),{mode:0o600});fs.renameSync(tmp,file);
   }
  }catch{probe.recordingError=true;}
 }
 return probe;
}
