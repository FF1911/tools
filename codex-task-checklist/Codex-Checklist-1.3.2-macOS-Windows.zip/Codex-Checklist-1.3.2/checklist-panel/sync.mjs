export function createSynchronizer({draw,fetchState,onConnection,onSynced=()=>{}}){
  let current=null,busy=false;
  function accept(result){
    if(result?.isError)throw new Error(result.structuredContent?.error?.message||'读取失败');
    const state=result?.structuredContent;
    if(!state?.taskId||!Array.isArray(state.plan)||!Number.isInteger(state.revision))return false;
    if(current&&current.taskId!==state.taskId)return false;
    // Historical tool results can arrive after the fresh stored version.
    if(current&&state.revision<current.revision)return false;
    if(!current||state.revision>current.revision){draw(state);current=state;}
    onConnection('');return true;
  }
  async function refresh(){
    if(!current||busy)return;
    busy=true;
    try{if(accept(await fetchState(current.taskId)))onSynced(current);}
    catch{onConnection('暂时无法同步，正在重试；已显示的进度会保留。');}
    finally{busy=false;}
  }
  return {accept,refresh,get state(){return current;},get delay(){return current?.plan.every(x=>['completed','cancelled'].includes(x.status))?20000:1500;}};
}
