import {createSynchronizer} from './sync.mjs';
export function restoredSelection(value){
  const s=value?.privateContent??value;
  return s?.schemaVersion===1&&typeof s.taskId==='string'&&/^[\da-f]{8}-[\da-f]{4}-[\da-f]{4}-[\da-f]{4}-[\da-f]{12}$/i.test(s.taskId)?s.taskId:null;
}
export function createPanelController({fetchState,draw,onStatus,onSelection,persist,onSynced=()=>{}}){
  let selected=null,generation=0,sync=null;
  async function select(taskId,{save=true}={}){
    const token=++generation;selected=taskId;sync=null;onSelection(taskId);onStatus(taskId?'正在读取…':'请选择清单');
    if(save){try{await persist({schemaVersion:1,taskId});}catch{if(token===generation)onStatus('无法保存选择，重开后可能需要重新选择。');}}
    if(token!==generation||!taskId)return;
    const next=createSynchronizer({fetchState,onSynced:s=>{if(token===generation)onSynced(s);},draw:s=>{if(token===generation)draw(s);},onConnection:m=>{if(token===generation)onStatus(m);}});
    try{
      const result=await fetchState(taskId);
      if(token!==generation)return;
      if(result.structuredContent?.taskId!==taskId||!next.accept(result))throw new Error('identity');
      sync=next;onSynced(next.state);
    }catch{if(token===generation)onStatus('暂时无法读取，正在重试；不会切换到其他清单。');}
  }
  async function refresh(){if(sync)await sync.refresh();else if(selected)await select(selected,{save:false});}
  return{select,refresh,get selected(){return selected;},get state(){return sync?.state??null;},get delay(){return sync?.delay??1500;}};
}
