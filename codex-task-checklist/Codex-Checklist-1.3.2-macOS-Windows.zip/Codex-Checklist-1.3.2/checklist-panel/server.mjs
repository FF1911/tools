import {createBackgroundReader} from './background-store.mjs';
import {McpServer} from '@modelcontextprotocol/sdk/server/mcp.js';
import {StdioServerTransport} from '@modelcontextprotocol/sdk/server/stdio.js';
import {registerAppTool,registerAppResource,RESOURCE_MIME_TYPE} from '@modelcontextprotocol/ext-apps/server';
import fs from 'node:fs';
import {checklistStorePath} from '../runtime-paths.mjs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {createVocReader} from './voc-store.mjs';
import {probeResult} from './session-probe.mjs';
import {ReadStore,idSchema} from './read-store.mjs';
import {uiResource,PANEL_VERSION,PANEL_TITLE,LEGACY_URI} from './ui-resource.mjs';
import {z} from 'zod';
import {ConversationStore,conversationKey} from './conversation-store.mjs';
const root=path.dirname(fileURLToPath(import.meta.url));
const store=new ReadStore(checklistStorePath());
const conversations=new ConversationStore(store.root,id=>store.read(id));
const server=new McpServer({name:'checklist-panel',version:PANEL_VERSION});
const resource=uiResource(fs.readFileSync(path.join(root,'dist/panel.html'),'utf8'));
const uri=resource.uri;
const backgroundRead=createBackgroundReader(path.join(root,'background-bindings.json'));
const annotations={readOnlyHint:true,destructiveHint:false,openWorldHint:false};
const result=data=>({content:[{type:'text',text:JSON.stringify(data)}],structuredContent:data});
const vocRead=createVocReader(root,process.env.VOC_PANEL_BINDINGS||path.join(root,'voc-bindings.json'));
const safe=(method,fn)=>async (args,extra)=>{try{return {...result(await fn(args,extra)),_meta:{'checklistPanel/identityProbe':probeResult(root,method,extra)}};}catch(e){console.error(e.message);return{...result({error:{message:['resolve_panel_context','select_panel_checklist','open_checklist_panel'].includes(method)?e.message:'无法读取这份清单。请刷新列表或检查保存文件。'}}),isError:true};}};
const documents=new Map([[uri,resource.html],[LEGACY_URI,resource.html]]);
const archive=path.join(root,'dist/resources');
if(fs.existsSync(archive))for(const file of fs.readdirSync(archive)){
 if(!/^dual-card-[a-f0-9]{64}\.html$/.test(file))continue;
 const saved=uiResource(fs.readFileSync(path.join(archive,file),'utf8'));
 if(file!==`dual-card-${saved.hash}.html`)throw Error('面板归档校验失败');
 documents.set(saved.uri,saved.html);
}
for(const [resourceUri,html] of documents){
 registerAppResource(server,resourceUri===uri?'checklist-panel':resourceUri===LEGACY_URI?'checklist-panel-legacy':`checklist-panel-${resourceUri.split('/').pop()}`,resourceUri,{},async()=>({contents:[{uri:resourceUri,mimeType:RESOURCE_MIME_TYPE,text:html,_meta:{ui:{prefersBorder:false,csp:{connectDomains:[],resourceDomains:[]}},'openai/ui':{availableDisplayModes:['inline','fullscreen'],preferredDisplayMode:'fullscreen'},'openai/widgetDescription':'紧凑双卡片面板：任务清单与 VOC 各阶段实时进度。'}}]}));
}
registerAppTool(server,'open_checklist_panel',{
  title:PANEL_TITLE,description:'在独立侧栏打开清单面板，会话内原卡保留。来自任务卡按钮的请求应传该taskId，只显示已有任务，不创建或修改进度；传taskId时保存当前会话的选择。无参数时恢复原有选择或本会话最近创建的清单；VOC跟随清单。',inputSchema:{taskId:idSchema.optional()},annotations:{...annotations,readOnlyHint:false},
  _meta:{ui:{resourceUri:uri},'openai/ui':{entrypoints:[{type:'thread'}]}}
},safe('open_checklist_panel',({taskId},extra)=>{
 const key=conversationKey(extra);let context=conversations.resolve(key);
 if(taskId!==undefined){
  store.read(taskId);
  if(!key)throw Error('宿主未提供会话标识，未保存侧栏选择。请从面板中选择这份清单。');
  context=conversations.select(key,taskId,context.selectionRevision);
  if(context.conflict||context.taskId!==taskId)throw Error('另一处刚改变了本会话的侧栏选择，请重试；未覆盖新的选择。');
 }
 return{kind:'checklist-panel',uiVersion:PANEL_VERSION,resourceUri:uri,...store.list(),context};
}));
server.registerTool('resolve_panel_context',{title:'恢复本会话清单',description:'根据宿主会话标识读取已保存选择和本会话自动关联，不写入状态。',inputSchema:{},annotations,_meta:{ui:{visibility:['app']}}},safe('resolve_panel_context',(_,extra)=>conversations.resolve(conversationKey(extra))));
server.registerTool('select_panel_checklist',{title:'记住本会话清单选择',description:'仅保存当前会话的面板选择，不修改清单。taskId 为 null 时恢复自动匹配；版本冲突返回最新选择，不覆盖。',inputSchema:{taskId:idSchema.nullable(),expectedRevision:z.number().int().nonnegative(),expectedConversationKey:z.string().regex(/^[a-f0-9]{64}$/)},annotations:{...annotations,readOnlyHint:false},_meta:{ui:{visibility:['app']}}},safe('select_panel_checklist',({taskId,expectedRevision,expectedConversationKey},extra)=>{const key=conversationKey(extra);if(key!==expectedConversationKey)throw Error('会话已切换，未保存旧面板的选择');return conversations.select(key,taskId,expectedRevision);}));
server.registerTool('list_panel_checklists',{title:'列出可查看的清单',description:'只读获取本机已保存清单的标题和版本，不改变面板选择。',inputSchema:{},annotations,_meta:{ui:{visibility:['app']}}},safe('list_panel_checklists',()=>store.list()));
server.registerTool('read_panel_checklist',{title:'读取所选清单',description:'只读获取指定 taskId 的最新保存版本，不修改清单。',inputSchema:{taskId:idSchema},annotations,_meta:{ui:{visibility:['app']}}},safe('read_panel_checklist',({taskId})=>store.read(taskId)));
server.registerTool('read_voc_progress',{title:'读取 VOC 实时进度',description:'按已登记清单绑定只读读取配额、采集和语料计数。不启动或控制任务。',inputSchema:{taskId:idSchema},annotations,_meta:{ui:{visibility:['app']}}},safe('read_voc_progress',({taskId})=>vocRead(taskId)));
server.registerTool('read_background_tasks',{title:'读取后台任务进展',description:'只读当前清单绑定的本机子代理记录，不启动或控制任务。',inputSchema:{taskId:idSchema},annotations,_meta:{ui:{visibility:['app']}}},safe('read_background_tasks',({taskId})=>backgroundRead(taskId)));
await server.connect(new StdioServerTransport());
