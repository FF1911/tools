const phases={pending:'',in_progress:'进行中',completed:'',blocked:'等待处理',cancelled:'已取消'};
const marks={pending:'',in_progress:'',completed:'',blocked:'!',cancelled:'–'};
export function mountChecklist(document){
  const card=document.querySelector('#checklist'),list=card.querySelector('ol'),rows=new Map();
  return state=>{
    const ids=new Set(state.plan.map(x=>x.id));
    for(const [id,row] of rows)if(!ids.has(id)){row.remove();rows.delete(id);}
    state.plan.forEach((step,index)=>{
      let row=rows.get(step.id);
      if(!row){
        row=document.createElement('li');row.dataset.stepId=step.id;
        for(const className of ['mark','body','phase']){const el=document.createElement('span');el.className=className;row.append(el);}
        for(const className of ['label','note']){const el=document.createElement('span');el.className=className;row.querySelector('.body').append(el);}
        row.querySelector('.mark').setAttribute('aria-hidden','true');rows.set(step.id,row);
      }
      if(list.children[index]!==row)list.insertBefore(row,list.children[index]??null);
      row.dataset.status=step.status;
      row.querySelector('.mark').textContent=marks[step.status];
      row.querySelector('.label').textContent=step.step;
      row.querySelector('.note').textContent=step.note??'';
      row.querySelector('.note').hidden=!step.note;
      row.querySelector('.phase').textContent=phases[step.status];
      row.setAttribute('aria-label',`${step.step}，${step.status==='completed'?'已完成':phases[step.status]||'待执行'}${step.note?'，'+step.note:''}`);
    });
    card.querySelector('#title').textContent=state.title;
    card.querySelector('#count').textContent=state.plan.filter(x=>x.status==='completed').length+' / '+state.plan.length+' 已完成';
    let saved=card.querySelector('#saved-state');if(!saved){saved=document.createElement('div');saved.id='saved-state';saved.style.cssText='font-size:11px;opacity:.65;margin-top:8px';card.append(saved);}
    saved.textContent='状态保存：'+new Date(state.updatedAt).toLocaleTimeString()+' · 版本 '+state.revision;
    saved.title='此时间是执行助手最后更新清单的时间，组件读取成功不代表任务状态已被更新。';
    card.dataset.revision=String(state.revision);card.dataset.taskId=state.taskId;
  };
}

export function markSynced(document,state){
 const card=document.querySelector("#checklist");if(card.dataset.taskId!==state.taskId)return;
 let el=card.querySelector("#last-read");if(!el){el=document.createElement("div");el.id="last-read";el.style.cssText="font-size:11px;opacity:.65";card.append(el);}
 el.textContent="最近读取："+new Date().toLocaleTimeString();
 el.dataset.revision=String(state.revision);
}
