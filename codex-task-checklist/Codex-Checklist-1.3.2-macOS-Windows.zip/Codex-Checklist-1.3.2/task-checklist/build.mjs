import {build,transform} from 'esbuild';
import fs from 'node:fs';
const bundle=await build({entryPoints:['card.mjs'],bundle:true,format:'esm',write:false,minify:true});
const script=bundle.outputFiles[0].text.replaceAll('</script','<\\/script');
const html=`<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>任务清单</title>
<style>
:root{color-scheme:light dark;--mark-gray:light-dark(#808080,#a0a0a0);--done-text:light-dark(#777,#aaa)}*{box-sizing:border-box}body{margin:0;padding:0;font:14px/1.6 system-ui;color:var(--color-text-primary,light-dark(#242424,#ededed));background:transparent}
section{border:1px solid var(--color-border-primary,light-dark(#dedede,#454545));border-radius:14px;padding:16px 18px}header{display:flex;align-items:baseline;justify-content:space-between;gap:12px}#title{font-size:15px;overflow-wrap:anywhere}#count{font-size:12px;opacity:.65;white-space:nowrap}
ol{list-style:none;margin:12px 0 0;padding:0}li{display:flex;align-items:flex-start;gap:10px;padding:5px 0}.mark{position:relative;display:inline-flex;align-items:center;justify-content:center;flex:0 0 16px;width:16px;height:16px;margin-top:3px;border-radius:50%;color:var(--mark-gray);font:12px/1 system-ui}.body{flex:1;min-width:0}.label,.note{display:block;overflow-wrap:anywhere}.note{font-size:12px;opacity:.7}.phase{font-size:12px;line-height:22.4px;white-space:nowrap;color:var(--done-text)}
li[data-status=pending] .mark{border:1.6px dashed var(--mark-gray)}
li[data-status=completed] .mark{background:var(--mark-gray)}
li[data-status=completed] .mark::after{content:"";width:4px;height:8px;border:solid #fff;border-width:0 1.7px 1.7px 0;transform:translateY(-1px) rotate(40deg)}
li[data-status=completed] .body{color:var(--done-text)}
li[data-status=in_progress] .mark{border:1.8px solid light-dark(#e2e2e2,#484848);border-top-color:var(--mark-gray);border-right-color:var(--mark-gray);animation:checklist-spin .9s linear infinite}
@keyframes checklist-spin{to{transform:rotate(360deg)}}
@media(prefers-reduced-motion:reduce){li[data-status=in_progress] .mark{animation:none}}
li[data-status=blocked] .mark{border:1.6px solid light-dark(#916100,#edbe58);color:light-dark(#916100,#edbe58)}li[data-status=cancelled]{opacity:.55}li[data-status=cancelled] .mark{border:1.6px solid var(--mark-gray)}#connection{margin-top:10px;font-size:12px;opacity:.7}[hidden]{display:none!important}
.header-actions{display:flex;align-items:center;justify-content:flex-end;gap:10px;flex-wrap:wrap;flex-shrink:0}#return-inline,#show-sidebar{font:inherit;font-size:12px;line-height:1.5;color:inherit;background:transparent;border:1px solid var(--color-border-primary,light-dark(#dedede,#454545));border-radius:7px;padding:4px 8px;cursor:pointer;white-space:nowrap}#show-sidebar:hover{background:light-dark(#f4f4f4,#303030)}#show-sidebar:disabled{opacity:.5;cursor:wait}#show-sidebar:focus-visible{outline:2px solid currentColor;outline-offset:2px}#display-message{margin-top:8px;font-size:12px}
@media(max-width:460px){header{flex-wrap:wrap;gap:6px}.header-actions{width:100%;justify-content:space-between}section{padding:12px}}
</style><section id="checklist" aria-label="任务清单"><header><strong id="title">任务清单</strong><div class="header-actions"><span id="count" role="status" aria-live="polite"></span><button id="return-inline" type="button" hidden>返回会话</button><button id="show-sidebar" type="button" hidden title="请求在独立侧栏面板显示，会话区原卡保留">在侧栏显示</button></div></header><ol></ol><div id="connection" role="status">正在读取进度…</div><div id="display-message" role="status" hidden></div></section><script type="module">${script}</script></html>`;
const scripts=[...html.matchAll(/<script[^>]*>([\s\S]*?)<\/script>/g)];if(scripts.length!==1)throw Error('Expected one final script');await transform(scripts[0][1],{loader:'js'});
fs.mkdirSync('dist',{recursive:true});fs.writeFileSync('dist/card.html',html);console.log('Built task checklist: '+Buffer.byteLength(html)+' bytes');
