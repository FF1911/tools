// The conversation card stays inline. Opening the independent panel is a user action.
const uuid=/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
export function mountDisplayControl({button,returnButton,message,getState,sendMessage,canMessage=()=>true}){
 let connected=false,busy=false,disposed=false;
 if(returnButton)returnButton.hidden=true;
 function render(){button.hidden=!connected;button.disabled=busy||!uuid.test(getState()?.taskId??'');}
 const click=async()=>{
  if(disposed||!connected||busy)return;
  const taskId=getState()?.taskId;if(!uuid.test(taskId??''))return;
  if(!canMessage()){message.textContent='请从会话工具栏打开「清单面板 · 双卡片」查看侧栏。';message.hidden=false;return;}
  busy=true;message.hidden=true;render();
  try{
   const result=await sendMessage({role:'user',content:[{type:'text',text:`请在侧栏显示已有任务清单，taskId=${taskId}。调用 checklist_panel 的 open_checklist_panel 并传入这个 taskId；保留会话区原卡，只显示已有数据，不新建任务或修改进度。`}]});
   if(disposed)return;
   if(result?.isError)throw Error('rejected');
   message.textContent='已发送侧栏显示请求；会话区任务卡保留在这里。';message.hidden=false;
  }catch{if(!disposed){message.textContent='侧栏显示请求未能发送。请重试，或从会话工具栏打开「清单面板 · 双卡片」。';message.hidden=false;}}
  finally{busy=false;if(!disposed)render();}
 };
 button.addEventListener('click',click);
 return{ready(){connected=true;render();},host(){},surface(){},stateChanged:render,dispose(){disposed=true;button.removeEventListener('click',click);}};
}
