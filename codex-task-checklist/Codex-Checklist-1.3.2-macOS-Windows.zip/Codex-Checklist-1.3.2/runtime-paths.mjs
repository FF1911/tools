import os from 'node:os';
import path from 'node:path';

export function checklistStorePath() {
  if (process.env.TASK_CHECKLIST_STORE) return process.env.TASK_CHECKLIST_STORE;
  if (process.platform === 'win32') {
    const local = process.env.LOCALAPPDATA || path.join(os.homedir(), 'AppData', 'Local');
    return path.join(local, 'CodexTaskChecklist');
  }
  return path.join(os.homedir(), 'Library', 'Application Support', 'CodexTaskChecklist');
}
