import {App} from '@modelcontextprotocol/ext-apps';
import {mountChecklist,markSynced} from './view.mjs';
import {createSynchronizer} from './sync.mjs';
import {mountDisplayControl} from './display.mjs';
const app=new App({name:'任务清单',version:'1.3.1'},{availableDisplayModes:['inline']},{autoResize:true});
const connection=document.querySelector('#connection');
const sync=createSynchronizer({draw:mountChecklist(document),
  onSynced:state=>markSynced(document,state),
  fetchState:taskId=>app.callServerTool({name:'sync_task_checklist',arguments:{taskId}}),
  onConnection:message=>{connection.textContent=message;connection.hidden=!message;}});
let timer,connected=false,stopped=false,polling=false;
const display=mountDisplayControl({button:document.querySelector('#show-sidebar'),returnButton:document.querySelector('#return-inline'),message:document.querySelector('#display-message'),getState:()=>sync.state,
 sendMessage:params=>app.sendMessage(params,{timeout:15000}),canMessage:()=>Boolean(app.getHostCapabilities()?.message?.text)});
async function tick(){
  clearTimeout(timer);
  if(stopped||!connected||polling||document.visibilityState==='hidden')return;
  polling=true;
  try{await sync.refresh();}
  finally{polling=false;if(!stopped&&document.visibilityState!=='hidden')timer=setTimeout(tick,sync.delay);}
}
app.ontoolresult=result=>{
  try{sync.accept(result);display.stateChanged();if(connected)void tick();}
  catch{connection.textContent='清单未能载入，请重开本会话。';connection.hidden=false;}
};
app.onhostcontextchanged=ctx=>display.host(ctx);
app.onteardown=async()=>{stopped=true;clearTimeout(timer);display.dispose();return {};};
try{await app.connect();connected=true;display.ready(app.getHostContext()||{});void tick();}
catch{connection.textContent='组件连接失败，请重开本会话。';connection.hidden=false;}
document.addEventListener('visibilitychange',()=>{if(document.visibilityState==='visible')void tick();else clearTimeout(timer);});
window.addEventListener('pagehide',()=>{stopped=true;clearTimeout(timer);});
window.addEventListener('pageshow',()=>{stopped=false;void tick();});
