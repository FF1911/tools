import fs from 'node:fs';
import path from 'node:path';
import {randomUUID} from 'node:crypto';
import {z} from 'zod';

export const idSchema=z.string().uuid();
export const stepSchema=z.object({
  id:z.string().regex(/^[A-Za-z0-9_-]{1,64}$/),
  step:z.string().trim().min(1).max(300),
  status:z.enum(['pending','in_progress','completed','blocked','cancelled']),
  note:z.string().trim().max(500).optional()
}).strict();
export const planSchema=z.array(stepSchema).min(1).max(30).superRefine((plan,ctx)=>{
  if(new Set(plan.map(x=>x.id)).size!==plan.length)ctx.addIssue({code:'custom',message:'步骤 ID 不能重复'});
  if(plan.filter(x=>x.status==='in_progress').length>1)ctx.addIssue({code:'custom',message:'同时最多一个步骤进行中'});
});
export const titleSchema=z.string().trim().min(1).max(120);
const stateSchema=z.object({schemaVersion:z.literal(1),taskId:idSchema,title:titleSchema,
  revision:z.number().int().nonnegative(),createdAt:z.string(),updatedAt:z.string(),plan:planSchema});
export class StateError extends Error{
  constructor(code,message,current){super(message);this.code=code;this.current=current;}
}

// Immutable revision files are published with an atomic, no-overwrite hard link.
// Two MCP processes can race; only one can publish a given revision.
export class ChecklistStore{
  constructor(root){this.root=root;fs.mkdirSync(root,{recursive:true,mode:0o700});}
  directory(id){return path.join(this.root,idSchema.parse(id));}
  read(id){
    const dir=this.directory(id);
    let files;
    try{files=fs.readdirSync(dir);}catch(e){if(e.code==='ENOENT')throw new StateError('NOT_FOUND','未找到这份清单');throw e;}
    const revisions=files.filter(f=>/^\d+\.json$/.test(f)).map(f=>Number(f.slice(0,-5)));
    if(!revisions.length)throw new StateError('NOT_FOUND','清单尚未保存');
    const rev=Math.max(...revisions);
    try{
      const state=stateSchema.parse(JSON.parse(fs.readFileSync(path.join(dir,rev+'.json'),'utf8')));
      if(state.taskId!==id||state.revision!==rev)throw new Error('identity');
      return state;
    }catch{throw new StateError('INVALID_STATE','清单保存文件损坏，已保留原文件，请检查后恢复');}
  }
  publish(state){
    const dir=this.directory(state.taskId),target=path.join(dir,state.revision+'.json');
    const temp=path.join(dir,'.'+randomUUID()+'.tmp');
    let fd;
    try{
      fd=fs.openSync(temp,'wx',0o600);
      fs.writeFileSync(fd,JSON.stringify(state,null,2));fs.fsyncSync(fd);fs.closeSync(fd);fd=undefined;
      fs.linkSync(temp,target);
      const directoryFd=fs.openSync(dir,'r');
      try{fs.fsyncSync(directoryFd);}finally{fs.closeSync(directoryFd);}
    }catch(e){
      if(e.code==='EEXIST')throw new StateError('REVISION_CONFLICT','清单已被另一处更新；请按最新状态合并后再提交',this.read(state.taskId));
      throw e;
    }finally{if(fd!==undefined)fs.closeSync(fd);fs.rmSync(temp,{force:true});}
    return state;
  }
  create(title,plan){
    title=titleSchema.parse(title);plan=planSchema.parse(plan);
    const taskId=randomUUID(),now=new Date().toISOString();
    fs.mkdirSync(this.directory(taskId),{mode:0o700});
    return this.publish({schemaVersion:1,taskId,title,revision:0,createdAt:now,updatedAt:now,plan});
  }
  update(taskId,expectedRevision,plan,title){
    plan=planSchema.parse(plan);if(title!==undefined)title=titleSchema.parse(title);
    const current=this.read(taskId);
    if(current.revision!==expectedRevision)throw new StateError('REVISION_CONFLICT','版本已变化；请按返回的最新清单合并后再提交',current);
    const next={...current,title:title??current.title,plan};
    if(JSON.stringify(next)===JSON.stringify(current))return current;
    return this.publish({...next,revision:current.revision+1,updatedAt:new Date().toISOString()});
  }
}
