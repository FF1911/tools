import {McpServer} from '@modelcontextprotocol/sdk/server/mcp.js';
import {StdioServerTransport} from '@modelcontextprotocol/sdk/server/stdio.js';
import {registerAppTool,registerAppResource,RESOURCE_MIME_TYPE} from '@modelcontextprotocol/ext-apps/server';
import {z} from 'zod';
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import {fileURLToPath} from 'node:url';
import {ChecklistStore,idSchema,planSchema,titleSchema,StateError} from './store.mjs';
import {ConversationStore,conversationKey} from './conversation-store.mjs';

const root=path.dirname(fileURLToPath(import.meta.url));
const store=new ChecklistStore(process.env.TASK_CHECKLIST_STORE||path.join(os.homedir(),'Library/Application Support/CodexTaskChecklist'));
const conversations=new ConversationStore(store.root,id=>store.read(id));
const uri='ui://task-checklist/card-v1.3.1-inline.html';
const legacyUri='ui://task-checklist/card-v1.html';
const server=new McpServer({name:'task-checklist',version:'1.3.1'});
const result=state=>({structuredContent:state,content:[{type:'text',text:JSON.stringify(state)}]});
const safe=(fn,{associate=false}={})=>async (args,extra)=>{
  try{
    const key=associate?conversationKey(extra):null,state=await fn(args);
    if(!associate)return result(state);
    let linked=false,warning=null;
    try{linked=conversations.associate(key,state);if(!key)warning='宿主未提供会话标识，清单已创建；首次在面板选择后可保存。';}
    catch{warning='清单已创建，但会话关联保存失败；可在面板中手动选择。';}
    return {...result(state),_meta:{'checklist/conversation':{linked,warning}}};
  }
  catch(e){
    const error={code:e instanceof StateError?e.code:'CHECKLIST_ERROR',message:e instanceof StateError?e.message:'清单操作失败，请检查本地服务与存储权限',...(e.current?{current:e.current}:{})};
    console.error(e);
    return {...result({error}),isError:true};
  }
};
const annotations={readOnlyHint:false,destructiveHint:false,openWorldHint:false};
const uiMeta={ui:{resourceUri:uri},'openai/outputTemplate':uri,'openai/ui':{preferredModelDisplayMode:'inline'}};
for(const resourceUri of [uri,legacyUri,'ui://task-checklist/card-v1.2.1.html','ui://task-checklist/card-v1.3.0-inline.html'])registerAppResource(server,resourceUri===uri?'task-checklist-card':`task-checklist-card-legacy-${resourceUri.includes('1.3.0')?'130':resourceUri.includes('1.2.1')?'121':'1'}`,resourceUri,{},async()=>({contents:[{
  uri:resourceUri,mimeType:RESOURCE_MIME_TYPE,text:fs.readFileSync(path.join(root,'dist/card.html'),'utf8'),
  _meta:{ui:{prefersBorder:false,csp:{connectDomains:[],resourceDomains:[]}},
    'openai/ui':{availableDisplayModes:['inline'],preferredDisplayMode:'inline'},
    'openai/widgetDescription':'常驻会话内的任务清单。侧栏由独立清单面板查看同一taskId，关闭侧栏后本卡仍保留；不将本卡切换到fullscreen。',
    'openai/widgetPrefersBorder':false}
}]}));
registerAppTool(server,'create_task_checklist',{
  title:'显示任务清单',
  description:'每个独立多步骤任务开始时调用一次，在当前消息处创建新清单；同一会话也可以有多个独立任务。新目标或独立交付不能改名覆盖旧清单，旧任务结果须保留。原任务的续做、修复或状态查询继续使用原taskId。通常3–7个中文步骤，稳定步骤ID，同时最多一个in_progress。保存taskId和revision，同一任务后续只更新原卡片。无需先打开侧栏。简单问答不调用。',
  inputSchema:{title:titleSchema,plan:planSchema},_meta:uiMeta,annotations
},safe(({title,plan})=>store.create(title,plan),{associate:true}));
server.registerTool('update_task_checklist',{
  title:'更新任务清单',
  description:'仅用于同一任务的进度、续做或修复，不生成新卡片。独立新目标或新交付应调用create_task_checklist，不能改名覆盖旧任务。传原taskId、最新expectedRevision、完整plan，保留已有步骤ID。实际完成才标记completed，等待用blocked附note，取消用cancelled，最多一个in_progress。版本冲突先读取合并，不盲目覆盖。',
  inputSchema:{taskId:idSchema,expectedRevision:z.number().int().nonnegative(),plan:planSchema,title:titleSchema.optional()},annotations
},safe(({taskId,expectedRevision,plan,title})=>store.update(taskId,expectedRevision,plan,title)));
server.registerTool('get_task_checklist',{
  title:'读取任务清单',description:'读取清单最新状态，不生成卡片。用于继续原任务或处理更新冲突。',
  inputSchema:{taskId:idSchema},annotations:{...annotations,readOnlyHint:true}
},safe(({taskId})=>store.read(taskId)));
registerAppTool(server,'reopen_task_checklist',{
  title:'重新显示任务清单',
  description:'用户要求重显，或任务收尾时侧栏关闭/不可确认可见时使用；读取原taskId显示同一份最新状态，不创建任务。普通更新不调用。',
  inputSchema:{taskId:idSchema},_meta:uiMeta,annotations:{...annotations,readOnlyHint:true}
},safe(({taskId})=>store.read(taskId)));
registerAppTool(server,'sync_task_checklist',{
  title:'同步任务进度',description:'清单组件读取最新保存状态。',
  inputSchema:{taskId:idSchema},_meta:{ui:{visibility:['app']}},annotations:{...annotations,readOnlyHint:true}
},safe(({taskId})=>store.read(taskId)));
await server.connect(new StdioServerTransport());
