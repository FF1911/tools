import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import {fileURLToPath} from 'node:url';
import {ReadStore,idSchema} from './read-store.mjs';
const [id,config]=process.argv.slice(2);
if(!id||!config||!path.isAbsolute(config))throw Error('用法：node bind-voc.mjs <taskId> <本机 config 绝对路径>');
idSchema.parse(id);
const task=new ReadStore(process.env.TASK_CHECKLIST_STORE||path.join(os.homedir(),'Library/Application Support/CodexTaskChecklist')).read(id);
const resolved=fs.realpathSync(config),cfg=JSON.parse(fs.readFileSync(resolved,'utf8'));
if(typeof cfg.db!=='string'||!fs.existsSync(path.resolve(path.dirname(resolved),cfg.db)))throw Error('配置或数据库不存在');
const file=process.env.VOC_PANEL_BINDINGS||path.join(path.dirname(fileURLToPath(import.meta.url)),'voc-bindings.json');
const lock=file+'.lock',fd=fs.openSync(lock,'wx'),temp=file+'.'+process.pid+'.tmp';
try{
 const bindings=JSON.parse(fs.readFileSync(file,'utf8'));
 if(bindings[id]&&bindings[id].config!==resolved)throw Error('已有不同项目绑定，请先核对，不自动覆盖');
 bindings[id]={skill:'voc-deepdive',config:resolved};
 fs.writeFileSync(temp,JSON.stringify(bindings,null,2)+'\n',{mode:0o600});fs.renameSync(temp,file);
 console.log(JSON.stringify({taskId:id,title:task.title,config:resolved,bound:true}));
}finally{fs.closeSync(fd);fs.unlinkSync(lock);if(fs.existsSync(temp))fs.unlinkSync(temp);}
