import fs from 'node:fs';
import path from 'node:path';
import {execFile} from 'node:child_process';
import {promisify} from 'node:util';
const run=promisify(execFile);
export function createVocReader(root,bindingsFile){
 const cache=new Map();
 return async taskId=>{
  const bindings=JSON.parse(fs.readFileSync(bindingsFile,'utf8'));
  const binding=bindings[taskId];if(!binding)return {taskId,available:false};
  if(binding.skill!=='voc-deepdive'||!path.isAbsolute(binding.config))throw Error('无效的项目绑定');
  const key=taskId+'\0'+binding.config,previous=cache.get(key);
  if(previous&&Date.now()-previous.at<4000)return previous.promise;
  const promise=run('/usr/bin/python3',[path.join(root,'voc-reader.py'),binding.config],{timeout:5000,maxBuffer:256*1024,env:{...process.env,VOC_DRIVE_NO_NOTIFY:'1',PYTHONDONTWRITEBYTECODE:'1'}})
   .then(({stdout})=>({taskId,available:true,...JSON.parse(stdout)}));
  cache.set(key,{at:Date.now(),promise});try{return await promise;}catch(e){cache.delete(key);throw e;}
 };
}
