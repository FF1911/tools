#!/usr/bin/env python3
"""Install both Codex MCP servers or roll back the most recent installation."""

import argparse
import fcntl
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tempfile
import tomllib
from datetime import datetime, timezone

PACKAGE = Path(__file__).resolve().parent
COMPONENTS = {"task_checklist": "task-checklist", "checklist_panel": "checklist-panel"}
TARGET_TABLE = re.compile(r"^\s*\[mcp_servers\.(task_checklist|checklist_panel)(?:\.[\w-]+)*\]\s*(?:#.*)?$")
TABLE_START = re.compile(r"^\s*\[{1,2}[^\]]+\]{1,2}\s*(?:#.*)?$")


def read_optional(path):
    return path.read_bytes() if path.exists() else None


def atomic_write(path, data, *, mode=0o600):
    with tempfile.NamedTemporaryFile(dir=path.parent, prefix=".checklist-", delete=False) as stream:
        temporary = Path(stream.name)
        try:
            os.fchmod(stream.fileno(), mode)
            stream.write(data)
            stream.flush()
            os.fsync(stream.fileno())
            os.replace(temporary, path)
        finally:
            temporary.unlink(missing_ok=True)


def checksum(data):
    return hashlib.sha256(data).hexdigest()


def toml_value(value):
    if isinstance(value, str):
        return json.dumps(value, ensure_ascii=False)
    if isinstance(value, bool):
        return str(value).lower()
    if isinstance(value, (int, float)):
        return str(value).lower()
    if isinstance(value, list):
        return "[" + ", ".join(map(toml_value, value)) + "]"
    if isinstance(value, dict):
        return "{ " + ", ".join(f"{toml_value(key)} = {toml_value(item)}" for key, item in value.items()) + " }"
    raise ValueError("已有 MCP 配置含安装器无法迁移的值类型。")


def former_component(settings, name):
    if not settings:
        return None
    args = settings.get("args", [])
    if settings.get("url") or len(args) != 1 or Path(args[0]).name != "server.mjs":
        raise ValueError(f"发现同名配置 {name}，但入口不同，安装已停止。")
    entry = Path(args[0])
    if not entry.is_absolute() or not entry.is_file() or COMPONENTS[name] not in entry.parts:
        raise ValueError(f"无法识别 {name} 的旧版入口，安装已停止。")
    return entry.parent.resolve()


def rewrite_config(raw, settings):
    # Preserve unrelated TOML verbatim; verify the parsed result before changing the file.
    original = tomllib.loads(raw)
    expected = tomllib.loads(raw)
    hits = set()
    kept = []
    removing = False
    for line in raw.splitlines(keepends=True):
        segment = line.rstrip("\r\n")
        if TABLE_START.match(segment):
            target = TARGET_TABLE.match(segment)
            removing = bool(target)
            if target:
                hits.add(target[1])
        if not removing:
            kept.append(line)
    if not set(original.get("mcp_servers", {})).intersection(COMPONENTS).issubset(hits):
        raise ValueError("发现非标准形式的同名 MCP 配置，安装已停止。")

    text = "".join(kept).rstrip() + "\n\n"
    for server, values in settings.items():
        table = f"mcp_servers.{server}"
        text += f"[{table}]\n"
        for key, value in values.items():
            if key != "env":
                text += f"{toml_value(key)} = {toml_value(value)}\n"
        text += f"\n[{table}.env]\n"
        for key, value in values["env"].items():
            text += f"{toml_value(key)} = {toml_value(value)}\n"
        text += "\n"
        expected.setdefault("mcp_servers", {})[server] = values
    if tomllib.loads(text) != expected:
        raise ValueError("合并结果未保留全部原配置，安装已停止。")
    return text.encode()


def node_and_npm():
    node = shutil.which("node")
    npm = shutil.which("npm")
    if not node or not npm:
        raise ValueError("请先安装 Node.js 22 或更高版本，并确认终端可以运行 node 和 npm。")
    binary, major = json.loads(subprocess.check_output(
        [node, "-p", 'JSON.stringify([process.execPath, Number(process.versions.node.split(".")[0])])'],
        text=True,
    ))
    if major < 22:
        raise ValueError("当前 Node.js 低于 22，请升级后再运行安装。")
    return binary, npm


def install(config, installs):
    before = read_optional(config)
    raw = (before or b"").decode()
    existing = tomllib.loads(raw).get("mcp_servers", {})
    former = {name: former_component(existing.get(name), name) for name in COMPONENTS}
    default_store = Path.home() / "Library" / "Application Support" / "CodexTaskChecklist"
    stores = {
        Path(existing[name].get("env", {}).get("TASK_CHECKLIST_STORE", str(default_store))).expanduser()
        for name in COMPONENTS if name in existing
    }
    if len(stores) > 1 or any(not store.is_absolute() for store in stores):
        raise ValueError("现有清单和侧栏的数据路径不同或不是绝对路径，安装已停止。")
    store = next(iter(stores), default_store)
    node, npm = node_and_npm()

    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ-")
    slot = Path(tempfile.mkdtemp(prefix=stamp, dir=installs))
    release = slot / "release"
    release.mkdir()
    after = None
    try:
        for filename in ("package.json", "package-lock.json"):
            shutil.copyfile(PACKAGE / filename, release / filename)
        for directory in COMPONENTS.values():
            shutil.copytree(PACKAGE / directory, release / directory)
        old_panel = former["checklist_panel"]
        if old_panel:
            new_panel = release / "checklist-panel"
            for binding in ("voc-bindings.json", "background-bindings.json"):
                source = old_panel / binding
                if source.is_file():
                    atomic_write(new_panel / binding, source.read_bytes())
            archive = new_panel / "dist" / "resources"
            archive.mkdir(exist_ok=True)
            old_dist = old_panel / "dist"
            for file in [old_dist / "panel.html", *(old_dist / "resources").glob("dual-card-*.html")]:
                if file.is_file():
                    data = file.read_bytes()
                    target = archive / f"dual-card-{checksum(data)}.html"
                    if not target.exists():
                        atomic_write(target, data)

        settings = {}
        for server, directory in COMPONENTS.items():
            values = dict(existing.get(server, {}))
            values.setdefault("startup_timeout_sec", 15)
            values.setdefault("tool_timeout_sec", 30)
            values.update(command=node, args=[str(release / directory / "server.mjs")], enabled=True)
            values["env"] = dict(values.get("env", {}), TASK_CHECKLIST_STORE=str(store))
            settings[server] = values
        after = rewrite_config(raw, settings)
        subprocess.run(
            [npm, "ci", "--omit=dev", "--ignore-scripts", "--no-audit", "--no-fund"],
            cwd=release, check=True,
        )
        # Resolve dependencies and validate archived UI resources before enabling the servers.
        with tempfile.TemporaryDirectory(prefix="checklist-probe-") as probe:
            for values in settings.values():
                env = dict(os.environ, **values["env"])
                env["TASK_CHECKLIST_STORE"] = probe
                subprocess.run([node, *values["args"]], input=b"", env=env, check=True, timeout=15)
        mode = config.stat().st_mode & 0o777 if config.exists() else 0o600
        if before is not None:
            atomic_write(slot / "config.before.toml", before)
        receipt = {"after_sha256": checksum(after), "existed": before is not None, "mode": mode}
        atomic_write(slot / "receipt.json", json.dumps(receipt).encode())
        if read_optional(config) != before:
            raise ValueError("安装期间 config.toml 已变化，请重试。")
        atomic_write(config, after, mode=mode)
    except BaseException:
        # Keep the only rollback record if an exception follows the atomic config switch.
        receipt_path = slot / "receipt.json"
        if after is None or not receipt_path.exists() or read_optional(config) != after:
            shutil.rmtree(slot)
        raise
    print("已安装任务清单 1.3.1 和侧栏。请完全退出并重新打开 Codex。")
    print(f"清单数据目录：{store}")


def rollback(config, installs):
    slots = sorted(
        (slot for slot in installs.iterdir() if (slot / "receipt.json").is_file() and not (slot / "rolled-back").exists()),
        reverse=True,
    )
    if not slots:
        raise ValueError("没有可回退的安装记录。")
    slot = slots[0]
    receipt = json.loads((slot / "receipt.json").read_text())
    current = read_optional(config)
    if current is None or checksum(current) != receipt["after_sha256"]:
        raise ValueError(f"config.toml 自安装后有改动，未覆盖。请参考安装备份：{slot}")
    before = (slot / "config.before.toml").read_bytes() if receipt["existed"] else None
    if read_optional(config) != current:
        raise ValueError("回退期间 config.toml 已变化，请先核对。")
    if before is not None:
        atomic_write(config, before, mode=receipt["mode"])
    else:
        config.unlink()
    atomic_write(slot / "rolled-back", b"")
    print("已回退 MCP 配置。任务数据保留，请重新打开 Codex。")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action", choices=["install", "rollback"], nargs="?", default="install")
    args = parser.parse_args()
    home = Path(os.environ.get("CODEX_HOME", str(Path.home() / ".codex"))).expanduser().resolve()
    home.mkdir(parents=True, exist_ok=True, mode=0o700)
    config = home / "config.toml"
    if config.is_symlink():
        raise ValueError("config.toml 是符号链接，请先检查其归属。")
    installs = home / "tools" / "checklist-bundle" / "installations"
    installs.mkdir(parents=True, exist_ok=True, mode=0o700)
    with (installs / ".lock").open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        if args.action == "install":
            install(config, installs)
        else:
            rollback(config, installs)


if __name__ == "__main__":
    try:
        main()
    except (OSError, ValueError, subprocess.SubprocessError) as exc:
        sys.exit(f"未完成操作：{exc}")
